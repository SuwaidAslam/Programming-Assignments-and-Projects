#include <iostream>
using namespace std;
int main()
{
    int a;
    cout<<"Enter your makers: "<<endl;
    cin>>a;
    if(a>=0 && a<=100){
        if(a>=50 && a<=59)
        cout<<"Your Grade is D"<<endl;
        else if(a>=60 && a<=69)
        cout<<"Your Grade is C"<<endl;
        else if(a>=70 && a<=79)
        cout<<"Your Grade is B"<<endl;
        else if(a>=80 && a<=100)
        cout<<"Your Grade is A"<<endl;
        else
        cout<<"Your Grade is F"<<endl;
    }
    else{
        cout<<"This is not a valid input"<<endl;
    }
    return 0;
}
