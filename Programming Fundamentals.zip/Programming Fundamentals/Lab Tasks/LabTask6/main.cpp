#include <iostream>
using namespace std;
int main(){
	int units,b,c,e;
    cout<<"Enter Units: ";
    cin>>units;
    if(units>=0)
    {
    	if(units>=0&&units<=100)
    	{
    		b=units*10;
    		cout<<b;
		}
		else if (units>=101&&units<=200)
		{
			b=units-100;
			c=100*10+(b*20);
			cout<<c;
		}
		else if (units>=201&&units<=300)
		{
			b=units-200;
			c=100*10+100*20+(b*30);
			cout<<c;
		}
		else if (units>=301&&units<=400)
		{
			b=units-400;
			c=100*10+100*20+100*30+100*40+(b*50);
			cout<<c;
		}
		}
		else
		{
			cout<<"Not a valid Input";
		}
    return 0;
}
