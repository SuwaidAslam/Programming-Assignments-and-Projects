#include <iostream>
using namespace std;
const int size=200;
struct med_data
{
	int id;
	char name[20];
	int price;
	int quantity;
}*med;
void Getinput(med_data *med);
void DisplayMed(med_data *med);
void SearchMed(med_data *med);
int main() {
	char ask;
	med=new med_data[size];
	Getinput(med);
	cout<<"\tEnter 'D' to Display medicine with respect to quantity or Enter 'S' for Search medicine: ";
	cin>>ask;
	if(ask=='D')
	DisplayMed(med);
	else
	SearchMed(med);
	
	delete[] med;
	return 0;
}
void Getinput(med_data *med){
	int count=1;
	for(int i=0;i<size;i++){
		cout<<"\tEnter data of Medicine#"<<count;
		cout<<"\nEnter ID of the Medicine: ";
		cin>>med[i].id;
		cout<<"Enter Name of the Medicine: ";
		cin>>med[i].name;
		cout<<"Enter price of the Medicine: ";
		cin>>med[i].price;
		cout<<"Enter quanitiy of Medicine: ";
		cin>>med[i].quantity;
		count++;
	}
}
void DisplayMed(med_data *med){
	cout<<"\tData of Medicines with less than 15 quantity\n";
	int count=1;
	for(int i=0;i<size;i++){
		if(med[i].quantity<15)
	{   cout<<"\t\nMedicine#"<<count;
		cout<<"\nID of the Medicine: ";
		cout<<med[i].id;
		cout<<"\nName of the Medicine: ";
		cout<<med[i].name;
		count++;
	}
	}
}
void SearchMed(med_data *med){
	cout<<"Enter name of the medicine to find:\n";
	string name;
	cin>>name;
	bool b;  int i;
		for(i=0;i<size;i++){
		if(name==med[i].name){
		b=true;
		break;
	}
		else
		b=false;
	}
	if(b==true){
		cout<<"\nID of the Medicine: ";
		cout<<med[i].id;
		cout<<"\nName of the Medicine: ";
		cout<<med[i].name;
	}
	else
	cout<<"\nNot Found!";
} 
