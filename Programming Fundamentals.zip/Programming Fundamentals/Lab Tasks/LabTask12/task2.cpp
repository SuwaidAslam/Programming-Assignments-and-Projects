#include <iostream>
using namespace std;
int main(){
 char *str=new char[30];
 cout<<"Enter a string: ";
 getline(cin,str);
 int count=1;
 while(str[count])
 count++;
 cout<<"Number of words in the string are: "<<count;
 delete[] str;
	return 0;
}
