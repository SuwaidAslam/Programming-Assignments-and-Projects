#include <iostream>
using namespace std;
int main(){
    int a; int b; int c;
    cout<<"Input any three Numbers: ";
    cin>>a;
    cin>>b;
    cin>>c;
    if(a>b){
        if(a>c)
            cout<<a<<" is the largest number."<<endl;
        else
            cout<<c<<" is the largest number."<<endl;
    }
    else{
        if(b>c)
            cout<<b<<" is the largest number."<<endl;
        else
            cout<<c<<" is the largest number."<<endl;
    }
    return 0;
}