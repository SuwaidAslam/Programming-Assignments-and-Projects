#include <iostream>
using namespace std;
int main(){
    char user_input;
    cout<<"Enter a Character: ";
    cin>>noskipws>>user_input;
    if(user_input==' ')
    cout<<user_input<<" is a space"<<endl;
    else if(user_input>=0 || user_input<=9)
    cout<<user_input<<" is a digit"<<endl;
    return 0;
}