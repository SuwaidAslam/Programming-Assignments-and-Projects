#include <iostream>
using namespace std;
void selection_sort(int arr[],int k,int h);
int size;
int main() {
	cout<<"\t\tSelection sort Programe\n\n";
	int j;
	cout<<"Enter the size of the array: ";
	cin>>size;
	int arr[size];
	cout<<"Enter the elements of the array: ";
	for(int i=0;i<size;i++)
	cin>>arr[i];
	
	selection_sort(arr,0,size-1);
	cout<<"Sorted elements are: ";
	for(int i=0;i<size;i++)
	cout<<" "<<arr[i];
	
	return 0;
}

void selection_sort( int arr[], int k, int h ) {
	int j,temp,min;
	if(k==h)
	return;
	min=k;
	for(j=k+1;j<=h;j++)
	if(arr[j]<arr[min])
	min=j;
	if(k!=min){
		temp=arr[min];
		arr[min]=arr[k];
		arr[k]=temp;
	}
	selection_sort(arr,k+1,h);
}
