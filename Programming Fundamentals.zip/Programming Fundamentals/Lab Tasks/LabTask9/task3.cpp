#include <iostream>
using namespace std;
int ave(int arr[],int k);
int size;
int main() {
	int k=0;
	cout<<"Enter size of the array: ";
	cin>>size;
	int arr[size];
	cout<<"Enter the elements of the array: ";
	for(int i=0;i<size;i++)
	cin>>arr[i];
	cout<<"Average is= "<<ave(arr,k)/size;
	
	return 0;
}
int ave(int arr[],int k){
	if(k>=size)
	return 0;
	else{
		return arr[k]+ave(arr,k+1);
	}
}
