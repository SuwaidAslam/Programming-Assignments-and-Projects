#include <iostream>
using namespace std;
double power(double n,int p);
int main() {
	double n;
	int p;
	cout<<"Enter base in double: ";
	cin>>n;
	cout<<"Enter power: ";
	cin>>p;
	cout<<"Result is: "<<power(n,p);
	return 0;
}

double power(double n,int p){
	if(p<1)
	return 1;
	else
	return n*power(n,p-1);
}
