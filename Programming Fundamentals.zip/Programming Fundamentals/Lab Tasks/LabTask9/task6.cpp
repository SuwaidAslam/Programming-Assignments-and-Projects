#include <iostream>
using namespace std;
void swap(int a,int b);
int main() {
	int a,b;
	cout<<"Enter two numbers A and B: ";
	cin>>a>>b;
	cout<<"Before Swaping: "<<"A= "<<a<<" B= "<<b;
	cout<<endl;
	swap(a,b);
	return 0;
}

void swap(int a,int b){
	int temp;
	temp=a;
	a=b;
	b=temp;
	cout<<"After Swaping: "<<"A= "<<a<<" B= "<<b;
	
}
