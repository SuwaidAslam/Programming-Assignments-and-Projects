#include <iostream>
using namespace std;
int palindrome(int num);
int num, remainder,reversed_number;
int main() {
	cout<<"Enter a 5 digit number: ";
	cin>>num;
	palindrome(num);
	if(reversed_number==num){
    cout<<num<<" is a palindrome number";
	}
	else
	cout<<num<<" is not a palindrome number";
	return 0;
}

int palindrome(int num){
	if(num==0)
	return 1;
    else{
    remainder = num%10;
    reversed_number = reversed_number*10 + remainder;
    num /= 10;
    palindrome(num);
    }
    return reversed_number;
}
