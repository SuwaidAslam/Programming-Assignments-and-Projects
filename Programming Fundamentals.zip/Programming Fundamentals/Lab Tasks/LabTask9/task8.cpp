#include <iostream>
using namespace std;
void bubble_sort(int arr[],int size);
int size;
int main() {
	cout<<"\t\tBubble sort Programe\n\n";
	int j;
	cout<<"Enter the size of the array: ";
	cin>>size;
	int arr[size];
	cout<<"Enter the elements of the array: ";
	for(int i=0;i<size;i++)
	cin>>arr[i];
	
	bubble_sort(arr,size);
	cout<<"Sorted elements are: ";
	for(int i=0;i<size;i++)
	cout<<" "<<arr[i];
	
	return 0;
}

void bubble_sort( int arr[], int size ) {
	int j,temp;
	if(size==1)
	return;
	for(j=0;j<size-1;j++)
	if(arr[j]>arr[j+1]){
	    temp=arr[j];
		arr[j]=arr[j+1];
		arr[j+1]=temp;
}
	bubble_sort(arr,size-1);
}
