#include <iostream>
using namespace std;
int main(){
    char ch;
    int i=1;
    int ia=0;
    int ib=0;
    cout<<"Enter a or b: ";
    cin>>ch;
    while(i<=20){
        if(ch=='a'){
            ia++;
            cout<<"Enter a or b: ";
            cin>>ch;
        }
        else if(ch=='b'){
            ib++;
            cout<<"Enter a or b: ";
            cin>>ch;
        }
        i++;
    }
    cout<<"You entered 'a' for "<<ia<<" times"<<endl;
    cout<<"You entered 'b' for "<<ib<<" times"<<endl;
    return 0;
}
