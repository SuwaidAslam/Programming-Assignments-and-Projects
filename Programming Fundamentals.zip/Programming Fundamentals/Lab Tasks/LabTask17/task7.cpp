#include <iostream>
using namespace std;
void second_largest_number(int arr[4]);
int main() {
	int i,arr[4];
	cout<<"Input 4 numbers: ";
	for(i=0;i<4;i++)
	cin>>arr[i];
	
	second_largest_number(arr);
	
	
	return 0;
}

void second_largest_number(int arr[4]){
	int out,i,largest,second_large;
	largest=arr[0];
	for(i=0;i<4;i++){
			if(arr[0]<arr[i])
			arr[0]=arr[i];
			largest=arr[0];
	}
	second_large=arr[1];
	for(i=0;i<4;i++){
		if((arr[1]<arr[i])&&(arr[i]<largest))
		arr[1]=arr[i];
		second_large=arr[1];
	}
	cout<<"Second largest num is: "<<second_large;
}
