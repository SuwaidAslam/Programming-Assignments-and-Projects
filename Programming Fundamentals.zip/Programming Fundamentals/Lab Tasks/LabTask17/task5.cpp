#include <iostream>
using namespace std;
int showChoice(int a,char operators, int b);
int sum(int a, int b);
int subtract(int a, int b);
int multiply(int a, int b);
int divide(int a, int b);
int remainder(int a, int b);

int main(){
	int a , b;
	char operators;
	cout<<"Enter two operands and the operation you want to perform: ";
	cin>>a>>operators>>b;
	cout<<"Result is: "<<showChoice(a,operators,b);
}
int showChoice(int a,char operators, int b){
	int result;
	switch(operators){
		case'+':result=sum(a,b);
		break;
		case'-':result=subtract(a,b);
		break;
		case'/':result=divide(a,b);
		break;
		case'*':result=multiply(a,b);
		break;
		case'%':result=remainder(a,b);
		break;
	}
	return result;
}

int sum(int a, int b){
	int sum=0;
	sum=a+b;
	return sum;
}

int subtract(int a, int b){
	int subtract=0;
	subtract=a-b;
	return subtract;
}
int multiply(int a, int b){
	int multiply=1;
	multiply=a*b;
	return multiply;
}
int divide(int a, int b){
	int divide=1;
	divide=a/b;
	return divide;
}

int remainder(int a, int b){
	int remainder=1;
	remainder=a%b;
	return remainder;
}


