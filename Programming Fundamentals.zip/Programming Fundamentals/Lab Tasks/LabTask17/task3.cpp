#include <iostream>
using namespace std;
double power(double n, int p);
int main() 
{
	double n;
	int p=2;
	cout<<"Enter any double value: ";
	cin>>n;
	cout<<"Enter 0 if you dont want any power(Default will be 2) or else enter 1 to enter desired power: ";
	bool a;
	cin>>a;
	if(a==1)
	{
	cout<<"Enter power: ";
	cin>>p;
	cout<<power(n,p);
    }
	else if(a==0)
	cout<<"Answer is: "<<power(n,p);
	
	return 0;
}

double power(double n, int p)
{
	int i;
	double c=1;
	for(i=1;i<=p;i++)
	{
			c*=n;
	}
	return c;
}
