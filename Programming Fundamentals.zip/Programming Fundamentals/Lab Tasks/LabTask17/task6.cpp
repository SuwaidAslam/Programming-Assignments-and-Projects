#include <iostream>
using namespace std;
void largest_number(int arr[4]);
int main() {
	int i,arr[4];
	cout<<"Input 4 numbers: ";
	for(i=0;i<4;i++)
	cin>>arr[i];
	
	largest_number(arr);
	return 0;
}

void largest_number(int arr[4]){
	int out,i;
	for(i=0;i<4;i++){
			if(arr[0]<arr[i])
			arr[0]=arr[i];
	}
	cout<<"largest num is: "<<arr[0];
}
