#include <iostream>
using namespace std;
int a,b;
void zero_small(int &, int &);
int main() {
	cout<<"Enter First integrs: ";
	cin>>a;
	cout<<"Enter Second integrs: ";
	cin>>b;
	zero_small(a,b);
	cout<<"Value of A is: "<<a;
	cout<<endl;
	cout<<"Value of B is: "<<b;
	return 0;
}

void zero_small(int &x, int &y){
	if(a<b)
	a=0;
	else if(b<a)
	b=0;
}
