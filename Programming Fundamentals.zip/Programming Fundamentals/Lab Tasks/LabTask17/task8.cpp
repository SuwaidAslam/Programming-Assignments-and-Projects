#include <iostream>
using namespace std;
int s;
double average(int arr[]);
int main() {
	int arr[s],i;
	cout<<"Enter the size of the array: ";
	cin>>s;
	cout<<"Avarage number is = "<<average(arr);
	return 0;
}

double average(int arr[]){
	int sum=0,i,n;
	double result;
	cout<<"Enter elements of arrays to find average: ";
	for(i=0;i<s;i++)
	cin>>arr[i];
	for(i=0;i<s;i++)
	sum+=arr[i];
	result=sum/s;
	
	return result;
	
}
