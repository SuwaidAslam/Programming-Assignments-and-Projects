#include <iostream>
using namespace std;
int factorial(int b);

int main() {
	int input;
	cout<<"Enter the number of which you want to take factorial: ";
	cin>>input;
	cout<<"Factorial is= "<<factorial(input);
	return 0;
}
int factorial(int b){
	for(int i=b-1;i>=1;i--){
		b*=i;
	}
	return b;
}
