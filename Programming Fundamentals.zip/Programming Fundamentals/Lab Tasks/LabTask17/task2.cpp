#include <iostream>
using namespace std;
bool check_prime(int n);
int main()
{
  int n,m,p;
  cout << "Enter range of positive integers: ";
  cin>>m>>p;
  cout<<"Prime numbers are: ";
  for(n=m+1;n<p;n++)
{
    if (check_prime(n))
      cout <<" "<<n;
}
  return 0;
}

bool check_prime(int n)
{
  for(int i = 2; i <= n / 2; i++)
      if(n % i == 0)
      return false;
      
  return true;
}
