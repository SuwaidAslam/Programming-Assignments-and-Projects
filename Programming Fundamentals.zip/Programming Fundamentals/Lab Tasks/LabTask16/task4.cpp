//4.Write a program to reverse a string.  
#include <iostream>
#include <string>
using namespace std;
int main() {
	string str;
	char temp[100];
	cout<<"Enter a string: ";
	getline(cin,str);
	int length=str.length();
	int j=0;
	for(int i=length-1;i>=0;i--){
	temp[j]=str[i];
	j++;
	}
	cout<<"Reverse is: ";
	for(int k=0;k<=length;k++){
		cout<<temp[k];
	}
	return 0;
}
