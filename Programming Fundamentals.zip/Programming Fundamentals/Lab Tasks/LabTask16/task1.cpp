1.
#include <iostream>
using namespace std;
const int size=20;
struct date_of_birth{
int dd,mm,yy;
};
struct student{
	char name[30];
	int rollNumber;
	struct date_of_birth dob;
}stdinfo[size];
void input(student stdinfo[]);
void search_std(student stdinfo[]);
void multiple(student stdinfo[]);
void check_roll(student stdinfo[],int i);

int main() {
	int i;
	input(stdinfo);
	search_std(stdinfo);
	multiple(stdinfo);
	return 0;
}
void input(student stdinfo[]){
	int a=1;
	cout<<"Enter Students information:\n\n";
	for(int i=0;i<size;i++){
		cout<<"Student #"<<a<<endl;
		cout<<"Enter Name: ";
		cin>>stdinfo[i].name;
		check_roll(stdinfo,i);
		cout<<"Enter Date Of Birth:\n";
		cout<<"Day: ";
		cin>>stdinfo[i].dob.dd;
		cout<<"Month: ";
		cin>>stdinfo[i].dob.mm;
		cout<<"Year: ";
		cin>>stdinfo[i].dob.yy;
		a++;
	}
}
 void check_roll(student stdinfo[],int i){
	cout<<"Enter RollNum: ";
	cin>>stdinfo[i].rollNumber;
		for(int k=i-1;k>=0;k--){
		if(stdinfo[i].rollNumber==stdinfo[k].rollNumber){
			cout<<"Invalid! Enter Again: ";
	        cin>>stdinfo[i].rollNumber;
	    }
	        else
	        break;
	}
}
void search_std(student stdinfo[]){
	cout<<"\n\t\tList of Students above 7 months and 18 years:\n";
	for(int i=0;i<size;i++){
	if(stdinfo[i].dob.yy>18 && stdinfo[i].dob.mm>7){
		cout<<"Student Name: "<<stdinfo[i].name<<endl;
		cout<<"Student RollNo: "<<stdinfo[i].rollNumber<<endl;
	}
}	
}
void multiple(student stdinfo[]){
	cout<<"\n\t\tStudents whose roll numbers are multiple of 3:\n";
	for(int i=0;i<size;i++){
		if(stdinfo[i].rollNumber%3==0){
			cout<<"Student Name: "<<stdinfo[i].name<<endl;
			cout<<"Student RollNo: "<<stdinfo[i].rollNumber<<endl;
		}	
	}
}
