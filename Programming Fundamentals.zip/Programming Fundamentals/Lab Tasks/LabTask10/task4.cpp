#include <iostream>
#include <string>
using namespace std;
const int employees=10;
struct empinfo{
	string name;
	int salary;
	int hours_per_day;
}emp[employees];
int main() {
	int n=1,i;
	for(i=0;i<employees;i++){
		cout<<"\n\tInput Employee #"<<n<<endl;
		cout<<"\nEnter Name: ";
		cin>>emp[i].name;
		cout<<"\nEnter hours_per_day: ";
		cin>>emp[i].hours_per_day;
		n++;
	}
			cout<<"----------------------------------\n";
	int b=1;
	for(i=0;i<employees;i++){
	if(emp[i].hours_per_day<=8)
	    emp[i].salary=50;
	else if(emp[i].hours_per_day>8 && emp[i].hours_per_day<=11)
		emp[i].salary=100;
	else if(emp[i].hours_per_day>=12)
		emp[i].salary=150;
		cout<<"\n\n\tDisplay Employee #"<<b<<endl;
		cout<<"\nName: ";
		cout<<emp[i].name;
		cout<<"\nSalary: ";
		cout<<emp[i].salary;
		b++;
	}
	return 0;
}
