#include<iostream>
using namespace std;
const int size=25;
struct student {
     int rollno;
     string name;
     int s1,s2,s3;
}s[size];
void input(student s[]);
void output(student s[]);
int main()
{
  input(s);
  output(s);
return 0;
}
void input(student s[])
{
  int i;
  for(i=0;i<size;i++)
 { 
 cout<<endl<<"student# "<<i+1;
cout<<endl<<"Enter the roll no: ";
   cin>>s[i].rollno;
   cout<<endl<<"Enter the name: ";
   cin>>s[i].name;
   cout<<endl<<"Enter the marks of first subject: ";
   cin>>s[i].s1;
    cout<<endl<<"Enter the marks of second subject: ";
   cin>>s[i].s2;
    cout<<endl<<"Enter the marks of third subject: ";
    cin>>s[i].s3; 
 }
}
void output(student s[])
{
  int i;
  for(i=0;i<size;i++){
  	if((s[i].s1<33 && s[i].s2<33)||(s[i].s2<33 && s[i].s3<33)||(s[i].s1<33 && s[i].s3<33))
cout<<"\n\nRoll No: "<<s[i].rollno<<"\t Nam	e: "<<s[i].name<<" has failed in more than two subjects.\n";

}
}
