#include<iostream>
#include<string>
using namespace std;
const int size=50;
struct employee{ 
       int id;
       string name;
       char designation[20];
       int age;
       int salary; 
}emp[size];
void input(employee emp[]);
void output(employee emp[]);
void findbyid(employee emp[]);
void findbyage(employee emp[]);
void findbysalary(employee emp[]);
void findbyAgeSalary(employee emp[]);
void byname(employee emp[]);
void bynameandage(employee emp[]);
int main()
{
input(emp);
output(emp);
findbyid(emp);
findbyage(emp);
findbysalary(emp);
findbyAgeSalary(emp);
byname(emp);
bynameandage(emp);
  return 0;
}
void input(employee emp[])	
{
  int a=1;
  cout<<"\t\tEnter Empoyees Information.\n";
  for(int i=0;i<size;i++){
  cout<<endl<<"\t\tEmployee #:"<<a;
  cout<<endl<<"Enter the ID of empolyee :";
  cin>>emp[i].id;
   cout<<endl<<"Enter the name of empolyee :";
  cin>>emp[i].name;
   cout<<endl<<"Enter the designation of empolyee :";
  cin>>emp[i].designation;
   cout<<endl<<"Enter the age of empolyee :";
  cin>>emp[i].age;
   cout<<endl<<"Enter the salary of empolyee :";
  cin>>emp[i].salary;
  a++;
}
}
void output(employee emp[])
{
   int a=1;
   cout<<"\n\t\tDisplay Empoyees information\n\n.";
  for(int i=0;i<size;i++){ 
   cout<<endl<<"\tEmployee #:"<<a;
   cout<<endl<<"The ID of empolyee :"<<emp[i].id;
   cout<<endl<<"The name of empolyee :"<<emp[i].name;
   cout<<endl<<"The designation of empolyee :"<<emp[i].designation;
   cout<<endl<<"The age of empolyee :"<<emp[i].age;
   cout<<endl<<"The salary of empolyee :"<<emp[i].salary;
   a++;
}
}
//This function is called in findbyid funtion.
void opt(int j,employee emp[]){
  cout<<endl<<"Enter the ID to find the employee: ";
  cin>>j;
  for(int i=0;i<size;i++){
  if(j==emp[i].id){
  cout<<endl<<"Name:"<<emp[i].name;
  cout<<endl<<"Designation:"<<emp[i].designation;
   cout<<endl<<"Age:"<<emp[i].age;
    cout<<endl<<"salary:"<<emp[i].salary;
  }
} 
}
void findbyid(employee emp[])
{   
int i,j;
 cout<<"\n\t\tSearch List of all employees by their IDs.\n";
for(i=0;i<size;i++){
bool ask;
cout<<"\nEnter 1 to enter to search OR Enter 0 to exit:";
cin>>ask;
if(ask==1)
opt(j,emp);
else if(ask==0)
break;
}
}
void findbyage(employee emp[])
{
 int i;
 cout<<"\n\t\tList of Employees whose age is greater than 50\n\n"<<endl;
 for(i=0;i<size;i++)
 if(emp[i].age>50){
 cout<<endl<<"ID is :"<<emp[i].id;
 cout<<endl<<"Name: "<<emp[i].name;
 cout<<endl<<"Designation: "<<emp[i].designation;
 cout<<endl<<"Age: "<<emp[i].age;
 cout<<endl<<"Salary: "<<emp[i].salary;
  }
}
void findbysalary(employee emp[])
{
  int i;
  cout<<"\n\t\tList of Employees whose salary is less than 50000\n\n";
  for(i=0;i<size;i++)
  if(emp[i].salary<50000){
  cout<<endl<<"ID is :"<<emp[i].id;
  cout<<endl<<"Name: "<<emp[i].name;
  cout<<endl<<"Designation: "<<emp[i].designation;
   cout<<endl<<"Age: "<<emp[i].age;
  cout<<endl<<"Salary: "<<emp[i].salary;
  }
}
void findbyAgeSalary(employee emp[])
{
  int i;
  cout<<endl<<"\n\t\tListEmployees whose salary is more than 50000 And Age is b/w 40 and 50\n\n";
  for(i=0;i<size;i++){
  if(emp[i].age>=40 && emp[i].age<=50 && emp[i].salary>50000){
   cout<<endl<<"ID is :"<<emp[i].id;
   cout<<endl<<"Name: "<<emp[i].name;
   cout<<endl<<"Designation: "<<emp[i].designation;
   cout<<endl<<"Age: "<<emp[i].age;
   cout<<endl<<"Salary: "<<emp[i].salary;
   }
}
}
void byname(employee emp[]){
    int i,j;
    cout<<"\n\t\tList of employees whose name starts with alphabet 'A' or 'a'.\n\n";
        for(i=0;i<size;i++)
        {
        if((emp[i].name[0]=='A')|| (emp[i].name[0]=='a')){
        	 cout<<"\nName: "<<emp[i].name;
		}
       }
}
void bynameandage(employee emp[])
{
    int i,j;
    cout<<"\n\t\tLists of employees whose name ends with alphabet 'N' or 'n' and also their age is less than 40.\n\n";
        for(i=0;i<size;i++)
        {
        int lastIndex = emp[i].name.length()-1;
        if((emp[i].name[lastIndex]=='N'&& emp[i].age<40) || (emp[i].name[lastIndex]=='n'&& emp[i].age<40))
        cout<<"\nName: "<<emp[i].name;
       }
}


