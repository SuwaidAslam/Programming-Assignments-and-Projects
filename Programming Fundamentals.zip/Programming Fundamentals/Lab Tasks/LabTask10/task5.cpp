#include <iostream>
using namespace std;
struct date{
	int day;
	int month;
	int year;
};

int main() {
	int d=13,m=4,y=2020,in,temp,temp2;
	date dt={d,m,y};
	cout<<"Today date is:\n\n";
	cout<<dt.day<<"/"<<dt.month<<"/"<<dt.year<<"\n\n";
	cout<<"Enter how many days from now:\n";
	cin>>in;
	dt.day=d+in;
	while(dt.day>30)
	{
		temp=dt.day-30;
		dt.day=1;
		dt.day+=temp;
		dt.month+=1;
	}
	while(dt.month>12){
			temp2=dt.month-12;
			dt.month=1;
			dt.month+=temp2;
			dt.year+=1;
		}
		
	cout<<"\n\nAfter "<<in<<" days date will be:\n\n";
	cout<<dt.day<<"/"<<dt.month<<"/"<<dt.year<<"\n";
	return 0;
}
