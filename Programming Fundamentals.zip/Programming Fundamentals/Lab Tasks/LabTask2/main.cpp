#include <iostream>
using namespace std;
int main(){
    int a;
    cout<<"Enter any desired number: ";
    cin>>a;
    if(a<0)
        cout<<"This is a Negaive number"<<endl;
    else if(a>0)
        cout<<"This is a Positive Number"<<endl;
    else if(a==0)
        cout<<"This is a zero"<<endl;
    return 0;
}