//2.Write a program to find a string "is" from a file data.txt.  
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
string find_is(string str);
int main()
{
	string str;
	ifstream file;
	file.open("data.txt",ios::in);
    getline(file,str);
    file.close();
    cout<<find_is(str);
    
	return 0;
}

string find_is(string str)
{
	bool check_flag;
    for(int i=0;i<str.length();i++)
	{
    	if(str.at(i)=='i' && str.at(i+1)=='s')
		{
    	check_flag=1;
    	break;
		}
	}
	
	if(check_flag==true)
	return "Yes, The string 'is' EXISTS in this file.";
	else
	return "No, The string 'is' does NOT exist in this file.";
}
