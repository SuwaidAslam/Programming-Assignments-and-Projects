/*4.Write a program that takes input in 50 employees(id, name, salary, age) 
and write their data in file employee.txt and find from file salary of an employee with id 13.*/
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
const int size=50;
struct employees
{
	int id;
	string name;
	int salary;
	int age;
}emp[size];
int main() 
{
	ofstream file;
	file.open("employee.txt",ios::out);
	cout<<"\t------Enter data in the file------\n";
	int count=1;
	for(int i=0;i<size;i++)
	{
		cout<<"\tEnter information of employee# "<<count<<endl;
		cout<<"Enter the age:\n";
		cin>>emp[i].age;
		file<<emp[i].age<<" ";
		cout<<"Enter the name:\n";
		cin>>emp[i].name;
		file<<emp[i].name<<" ";
		cout<<"Enter the id:\n";
		cin>>emp[i].id;
		file<<emp[i].id<<" ";
		cout<<"Enter the Salary:\n";
		cin>>emp[i].salary;
		file<<emp[i].salary<<endl;
		count++;
	}
	file.close();
	ifstream file2;
	file2.open("employee.txt",ios::in);
	int i=0;
   while (file2>> emp[i].age >> emp[i].name>> emp[i].id >>emp[i].salary)
    {
    if(emp[i].id==13)
	{
    	cout<<"Employee of ID= 13->"<<"Name: "<<emp[i].name<<"| Salary: "<<emp[i].salary<<endl;
	}
    i++;
    }
	file2.close();
	return 0;
}
