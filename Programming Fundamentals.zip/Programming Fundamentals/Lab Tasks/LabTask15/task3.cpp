/*3.Write a program that takes input in 100 students(id, name, age, gender) 
and write their data in file student.txt and find from file how many students are of age 18.*/
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
const int size=100;
struct student
{
	int id;
	string name;
	int age;
	string gender;
}stud[size];
int main()
{
	ofstream file;
	file.open("student.txt",ios::out);
	cout<<"\t------Enter data in the file------\n";
	int count=1;
	for(int i=0;i<size;i++)
	{
		cout<<"\tEnter info of Student# "<<count<<endl;
		cout<<"Enter the age:\n";
		cin>>stud[i].age;
		file<<stud[i].age<<" ";
		cout<<"Enter the name:\n";
		cin>>stud[i].name;
		file<<stud[i].name<<" ";
		cout<<"Enter the id:\n";
		cin>>stud[i].id;
		file<<stud[i].id<<" ";
		cout<<"Enter the gender:\n";
		cin>>stud[i].gender;
		file<<stud[i].gender<<endl;
		count++;
	}
	file.close();
	int cont=0;
	ifstream file2;
	file2.open("student.txt",ios::in);
	int i=0;
     while (file2>>stud[i].age>>stud[i].name>>stud[i].id>>stud[i].gender)
	 {
       if(stud[i].age==18)
	   {
	   	cont++;
	   }
	   i++;
     }
    cout<<cont<<" students are of age 18.";
	file2.close();
	return 0;
}
