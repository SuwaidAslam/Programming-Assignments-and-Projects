//1.Write a program to convert all the characters in uppercase in a file data.txt.  
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
string uppercase(string str);
int main() 
{
	string str;
	ifstream file;
	file.open("data.txt",ios::in);
	getline(file,str);
	file.close();
	ofstream file2;
	file2.open("data.txt",ios::out);
	file2<<uppercase(str);
	file2.close();
	cout<<"After execution of this program the data in txt file is: "<<str;
	return 0;
}

string uppercase(string str)
{
	for(int i=0;i<str.length();i++)
	{
   	if(str.at(i)>='a'&& str.at(i)<='z')
   	str.at(i)=str.at(i)-32;
    }
   return str;
}
