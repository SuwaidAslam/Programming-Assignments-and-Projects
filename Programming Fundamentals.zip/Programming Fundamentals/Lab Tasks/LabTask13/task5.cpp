#include <iostream>
#include <string>
using namespace std;
void LongestWord(string text);
void ShortestWord(string text);
int main()
{
	string text;
	cout<<"Enter a string: ";
	getline(cin,text);
	LongestWord(text);
	cout<<"--------------------------------------\n";
	ShortestWord(text);
    return 0;
}
void LongestWord(string text)
{
string tmpWord = "";
string maxWord = "";

for(int i=0; i < text.length(); i++)
{
    if(text[i] != ' ')
        tmpWord += text[i];
    else
        tmpWord = "";
    if(tmpWord.length() > maxWord.length())
        maxWord=tmpWord;
}
cout << "Longest Word: " << maxWord << endl;
cout << "Word Length: " << maxWord.length() << endl;
}

void ShortestWord(string text)
{
string tmpWord = "";
string minWord = text;

for(int i=0; i < (int)text.length(); i++)
{
    if(text[i] != ' ')
    {
        tmpWord += text[i];
    }
    else
    {
        if(tmpWord.length() < minWord.length())
            minWord=tmpWord;
        tmpWord = "";
    }

}
  if(tmpWord != "")
  {
     if(tmpWord.length() < minWord.length())
          minWord=tmpWord;
  }
cout << "Shortest Word: " << minWord << endl;
cout << "Word Length: " << minWord.length() << endl;
}

