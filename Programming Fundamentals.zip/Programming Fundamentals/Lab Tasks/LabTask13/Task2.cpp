#include <iostream>
#include <string>
using namespace std;
void reverse(string str);
int main() {
	cout<<"Enter a string: ";
	string str;
	getline(cin,str);
	reverse(str);
	return 0;
}
void reverse(string str){
	cout<<"Reversed string is: ";
	for(int k=str.length();k>=0;k--){
        cout<<str[k];
	}
}
