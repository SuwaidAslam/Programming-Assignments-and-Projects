#include <iostream>
#include <string>
using namespace std;
int main() 
{
	cout<<"Enter a string: ";
	string str;
	getline(cin,str);
	cout<<"The length of the string is: "<<str.length();
	return 0;
}
