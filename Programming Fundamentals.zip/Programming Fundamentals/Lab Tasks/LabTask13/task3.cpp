#include <iostream>
#include <string>
using namespace std;
int main() {
	cout<<"Enter first string: ";
	string str1;
	getline(cin,str1);
	cout<<"Enter second string: ";
	string str2;
	getline(cin,str2);
	cout<<"After Concatination ==> "<<str1.append(str2);//we can use both '+' or append() function to concatinate two strings
	return 0;
}
