#include <iostream>
#include <string>
using namespace std;
int main() 
{ 
   string str;
   cout<<"Enter a string to convert it to lowercase: ";
   getline(cin,str);
   for(int i=0;i<str.length();i++)
   {
   	if(str.at(i)>='A'&& str.at(i)<='Z')
   	str.at(i)=str.at(i)+32;
   }
   cout<<"In lowercase: "<<str;
   return 0;
}
