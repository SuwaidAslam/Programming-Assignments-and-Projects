#include <iostream>
#include <string>
using namespace std;
int main()
{
    string str;
    int i, j;
    cout << "Enter a string : ";
    getline(cin,str);
     cout << "\nResultant String : ";
    for(i = 0; str[i] != '\0'; ++i)
    {
    	if((str[i] >= 'a' && str[i] <= 'z') || (str[i] >= 'A' && str[i] <= 'Z') || str.at(i)==' ')
    	cout<<str.at(i);
}
    return 0;
}
