#include <iostream>
#include <string>
using namespace std;
int main() {
	string str1,str2,temp;
	string *ptr1,*ptr2,*ptrtemp;
	int i,j;
	cout<<"Enter string A: ";
	getline(cin,str1);
	cout<<"Enter string B: ";
	getline(cin,str2);
	
	ptr1=&str1;
	ptr2=&str2;
	//swaping
	ptrtemp=ptr1;
	ptr1=ptr2;
	ptr2=ptrtemp;
	
	cout<<"Now String A is= ";
	cout<<*ptr1;

	cout<<"\nNow String B is= ";
	cout<<*ptr2;
	return 0;
}


