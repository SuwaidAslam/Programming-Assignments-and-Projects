#include <iostream>
#include <string>
using namespace std;
int main() 
{ 
   string str;
   cout<<"Enter a string to convert it to uppercase: ";
   getline(cin,str);
   for(int i=0;i<str.length();i++){
   	if(str.at(i)>='a'&& str.at(i)<='z')
   	str.at(i)=str.at(i)-32;
   }
   cout<<"In uppercase: "<<str;
   return 0;
}
