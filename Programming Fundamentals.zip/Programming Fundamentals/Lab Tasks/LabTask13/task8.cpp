#include <iostream>
#include <string>
using namespace std;
int main() {
	string str;
	char temp[100];
	cout<<"Enter a string to check, if it is Palindrome or not: ";
	getline(cin,str);
	int length=str.length();
	int j=0;	
	for(int i=length-1;i>=0;i--){
	temp[j]=str[i];
	j++;
	}
	bool check;
	for(int k=0;k<=length;k++){
		if(temp[k]==str[k])
		check=true;
		else{
			check=false;
			break;
		}
	}
	if(check)
	cout<<"This string is palindrome.";
	else
	cout<<"This string is not palindrome.";
	return 0;
}
