#include <iostream>
using namespace std;
int main(){
	cout<<"Enter a number: ";
	int n;
	cin>>n;
	(n%2==0)? cout<<"This is an Even number."<<endl:cout<<"This is an Odd number."<<endl;
	return 0;
}
