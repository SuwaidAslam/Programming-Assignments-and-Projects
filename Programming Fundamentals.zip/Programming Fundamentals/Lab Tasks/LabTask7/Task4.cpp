#include <iostream>
using namespace std;
int main(){
    cout<<"Input an algebric expression: ";
    int a;
    char ch;
    int b;
    cin>>a>>ch>>b;
    switch(ch){
        case '+': cout<<"a+b= "<<a+b<<endl;
        break;
        case '-': cout<<"a-b= "<<a-b<<endl;
        break;
        case '/': cout<<"a/b= "<<a/b<<endl;
        break;
        case '%': cout<<"a%b= "<<a%b<<endl;
        break;
        case '*': cout<<"a*b= "<<a*b<<endl;
    }
    return 0;
}
