#include <iostream>
using namespace std;
int main() {
	cout<<"Input a character: ";
	char ch;
	cin>>ch;
	switch(ch){
		case 'a': cout<<"Is a vowel";
		break;
		case 'e': cout<<"Is a vowel";
		break;
		case 'i': cout<<"Is a vowel";
		break;
		case 'o': cout<<"Is a vowel";
		break;
		case 'u': cout<<"Is a vowel";
		break;
		case 'A': cout<<"Is a vowel";
		break;
		case 'E': cout<<"Is a vowel";
		break;
		case 'I': cout<<"Is a vowel";
		break;
		case 'O': cout<<"Is a vowel";
		break;
		case 'U': cout<<"Is a vowel";
		break;
		default:cout<<"Is a consonant"<<endl;
		
	}
	return 0;
}
