#include <iostream>
using namespace std;
void check_palindrome(char *ptr,int length);
int main() {
	char str[20];
	cout<<"Input a string: ";
	cin>>str;
	int length=0;
	while(str[length])
	length++;
	char *ptr=str;
	cout<<endl;
	check_palindrome(ptr,length);
	return 0;
}
void check_palindrome(char *ptr,int length){
	char st[length],rev[length];
	for(int i=0;i<length;i++){
		st[i]=*ptr;
		ptr++;
	}
	int m=0;
	for(int k=length-1;k>=0;k--){
        rev[m]=st[k];
        m++;
	}
	int n=0;
	bool check;
	for(int i=0;i<length;i++){
	if(rev[n]==st[i])
	check=true;
	else
	check=false;
	n++;
}
if(check==true)
cout<<"Entered string is a palindrome.";
else if(check==false)
cout<<"Entered string is not a palindrome.";
}
