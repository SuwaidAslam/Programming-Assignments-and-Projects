#include <iostream>
using namespace std;
void reverse(char *ptr, int length);
int main() {
	char str[20];
	cout<<"Enter a string: ";
	cin>>str;
	int length=0;
	while(str[length])
	length++;
	char *ptr=str;
	reverse(ptr,length);
	return 0;
}
void reverse(char *ptr, int length){
		char st[length];
	for(int i=0;i<length;i++){
		st[i]=*ptr;
		ptr++;
	}
	cout<<"Reversed string is : ";
	for(int k=length-1;k>=0;k--){
        cout<<st[k];
	}
}
