#include <iostream>
using namespace std;
int check_vowel(char *p,int length);
int main()
{
	char str[10];
	cout<<"Enter a string: ";
	cin>>str;
	char *p=str;
	int length=0;
	while(str[length])
	length++;
	cout<<"Number of vowels in this string are: "<<check_vowel(p,length);
	return 0;
}
int check_vowel(char *p,int length){
	int count;
	for(int i=0;i<length;i++)
	{
		if(*p=='A'||*p=='E'||*p=='I'||*p=='O'||*p=='U'||*p=='a'||*p=='e'||*p=='i'||*p=='o'||*p=='u')
		count++;
		p++;
	}
	return count;
}
