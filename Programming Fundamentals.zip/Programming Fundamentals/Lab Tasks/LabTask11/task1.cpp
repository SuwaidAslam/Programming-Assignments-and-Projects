#include <iostream>
using namespace std;
int main() {
	const int size=10;
	int a[size],sum=0;
	cout<<"Enter some numbers: ";
	for(int i=0;i<size;i++)
	cin>>a[i];
	int *p=a;
	for(int i=0;i<size;i++){
		sum+=*p;
		p++;
	}
	cout<<"Sum of all the numbers is= "<<sum;
	return 0;
}
