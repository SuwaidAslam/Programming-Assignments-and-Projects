#include <iostream>
using namespace std;
int check_occurences(char *ptr,char *pt,int length);
int main() {
	char str[20],chr;
	cout<<"Enter a string: ";
	cin>>str;
	cout<<"Enter a char to search in string: ";
	cin>>chr;
	int length=0;
	while(str[length])
	length++;
	char *ptr=str;
	char *pt=&chr;
	cout<<*pt<<"'s occurrences in string= "<<check_occurences(ptr,pt,length);
	
	return 0;
}
int check_occurences(char *ptr,char *pt,int length){
	int count=0;
	for(int i=0;i<length;i++){
		if(*pt==*ptr)
		count++;
		ptr++;
	}
	return count;
}
