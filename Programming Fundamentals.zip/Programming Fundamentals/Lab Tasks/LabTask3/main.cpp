#include <iostream>
using namespace std;
int main(){
    char user_input;
    cout<<"Enter any Character: ";
    cin>>user_input;
    if(user_input=='a' || user_input=='A')
        cout<<user_input<<" is a vowel"<<endl;
    else if(user_input=='e' || user_input=='E')
        cout<<user_input<<" is a vowel"<<endl;
    else if(user_input=='i' || user_input=='I')
        cout<<user_input<<" is a vowel"<<endl;
    else if(user_input=='o' || user_input=='O')
        cout<<user_input<<" is a vowel"<<endl;
    else if(user_input=='u' || user_input=='U')
        cout<<user_input<<" is a vowel"<<endl;
    else
        cout<<user_input<<" is a consonant"<<endl;
    return 0;
}