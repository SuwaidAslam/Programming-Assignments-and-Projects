//6.Write a program to remove all characters except Alphabets in a file data.txt. 
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
string remov(string strout);
int main() 
{
	cout<<"Enter a line of text: ";
	string str;
	getline(cin,str);
	string strout,str2;
	
	ofstream file;
	file.open("data.txt",ios::out);
	file<<str;
	file.close();
	ifstream readfile;
	readfile.open("data.txt",ios::in);
    getline(readfile,strout);
	readfile.close();
	ofstream file2;
	file2.open("data.txt",ios::out);
	str2=remov(strout);
	file2<<str2;
	file2.close();
	cout<<"Resultant string: ";
	cout<<str2;
	return 0;
}

string remov(string strout)
{
	string str;
	for(int i = 0; i<strout.length(); ++i)
    {
    	if((strout[i] >= 'a' && strout[i] <= 'z') || (strout[i] >= 'A' && strout[i] <= 'Z') || strout.at(i)==' ')
    	str+=strout.at(i);
    }
    return str;
}
