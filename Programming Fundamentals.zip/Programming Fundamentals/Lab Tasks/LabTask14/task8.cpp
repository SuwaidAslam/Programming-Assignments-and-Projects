//8.Write a program to find a string "to" from a file data.txt.  
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
int main() 
{
	string str,str2;
	cout<<"Enter the string data into the text file: ";
	getline(cin,str);
	ofstream file;
	file.open("data.txt",ios::out);
	file<<str;
	file.close();
	
	ifstream file2;
	file2.open("data.txt",ios::in);
    getline(file2,str2);
    file2.close();
    
    bool check_flag;
    for(int i=0;i<str2.length();i++)
	{
    	if(str2.at(i)=='t' && str.at(i+1)=='o')
		{
    	check_flag=1;
    	break;
		}
	}
	
	if(check_flag==true)
	cout<<"Yes, The string 'to' EXISTS in this file.";
	else
	cout<<"No, The string 'to' does NOT exist in this file.";
	
	return 0;
}
