//1.Write a program to count number of words in a data file data.txt.
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
int main() 
{
	string str,str2;
	cout<<"Enter data in the text file: ";
	getline(cin,str);
	
	ofstream write_file;
	write_file.open("data.txt",ios::out);
	write_file<<str;
	write_file.close();
	ifstream read_file;
	read_file.open("data.txt",ios::in);
    getline(read_file,str2);
    
    int count=0;
    for(int i=0;i<str2.length();i++)
	{
		   if(str2.at(i)!=' ')
		   {
		   		count++;
		   }
		   
	}
	cout<<"Line you entered: "<<str2<<endl;
	cout<<"Number of words in Data file: "<<count<<endl;
	read_file.close();
	
return 0;
}
