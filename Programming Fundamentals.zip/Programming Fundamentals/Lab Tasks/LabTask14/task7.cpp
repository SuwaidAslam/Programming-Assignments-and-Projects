//7.Write a program to convert all the characters in lowercase in a file data.txt.  
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
string lowercase(string strout);
int main() 
{
	cout<<"Enter string data in the text file: ";
	string str;
	getline(cin,str);
	string strout,str2;
	
	ofstream file;
	file.open("data.txt",ios::out);
	file<<str;
	file.close();
	fstream file2;
	file2.open("data.txt",ios::in);
    getline(file2,strout);
    file2.close();
    ofstream file3;
	file3.open("data.txt",ios::out);
    str2=lowercase(strout);
    file3<<str2;
	file3.close();
	cout<<"The Result that has been saved in the file===> "<<str2;
	return 0;
}
string lowercase(string strout)
{
	for(int i=0;i<strout.length();i++)
	{
   	if(strout.at(i)>='A'&& strout.at(i)<='Z')
   	strout.at(i)=strout.at(i)+32;
    }
   return strout;
}
