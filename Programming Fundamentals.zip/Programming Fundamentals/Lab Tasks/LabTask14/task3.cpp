//3.Write a program to display contents of even rows in a data file data.txt.
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
int main() 
{
	string str2;
	ifstream read_file;
	read_file.open("data.txt",ios::in);
    getline(read_file,str2);
    
    int count=1;
    string line;
     while (getline(read_file, line))
	 {
       ++count;
       if(count%2==0)
	   {
	   	    cout<<count<<"-"<<line<<endl;
	   }
       	
     }
	read_file.close();
	return 0;
}
