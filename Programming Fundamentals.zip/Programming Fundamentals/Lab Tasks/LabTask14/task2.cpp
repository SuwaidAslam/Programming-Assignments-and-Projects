//2.Write a program to count number of lines in a data file data.txt.
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
int main() 
{
	string str2;
	ifstream read_file;
	read_file.open("data.txt",ios::in);
    getline(read_file,str2);
    
    int count=1;
    string line_count;
     while (getline(read_file, line_count))
	 {
       ++count;
     }
	cout<<"The number of lines: "<<count<<endl;
	read_file.close();
	
return 0; 
}
