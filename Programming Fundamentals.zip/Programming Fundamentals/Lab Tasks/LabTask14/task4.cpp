//4.Write a program to write number 1 to 100 in a data file num.txt.
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
int main() 
{
	ofstream file;
	file.open("num.txt",ios::out);
	for(int i=1;i<=100;i++)
	{
		file<<"\t"<<i<<endl;
	}
	cout<<"------------1 to 100 numbers have been printed on file num.txt------------";
	file.close();
	return 0;
}
