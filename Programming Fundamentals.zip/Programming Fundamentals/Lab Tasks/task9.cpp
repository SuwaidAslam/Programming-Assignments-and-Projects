#include <iostream>
using namespace std;
int main(){
    char ch;
    cout<<"Enter z: ";
    cin>>ch;
    int iz=0;
    while(ch=='z'){
        iz++;
        cout<<"Enter z: ";
        cin>>ch;
    }
        cout<<"You have entered z "<<iz<<" times"<<endl;
    switch(ch){
    case '0':break;
    }
    return 0;
}
