#include <iostream>
using namespace std;
void max_number(int arr[4]){
	int o,i;
	for(i=0;i<4;i++){
			if(arr[0]<arr[i])
			arr[0]=arr[i];
	}
	cout<<"Max num is: "<<arr[0];
}

int main() {
	int i,arr[4];
	cout<<"Four numbers:  ";
	for(i=0;i<4;i++)
	cin>>arr[i];
	
	max_number(arr);
	return 0;
}
