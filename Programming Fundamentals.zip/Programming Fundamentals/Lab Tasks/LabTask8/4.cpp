#include <iostream>
using namespace std;
int m,n;
void zero_small(int &x, int &x);
int main() 
{
	cout<<"Enter two integrs: ";
	cin>>m>>n;
	zero_small(m,n);
	cout<<"Enter A "<<m;
	cout<<endl;
	cout<<"Enter B: "<<n;
	return 0;
}

void zero_small(int &x, int &y){
	if(m<n)
	m=0;
	else
	n=0;
}
