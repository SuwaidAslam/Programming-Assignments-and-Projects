#include <iostream>
using namespace std;
bool isPrime(int);
int main()
{
    int m, n, i;
    cout<<"Enter range: ";
    cin >> m >> n;

    for(i = m+1; i <n; i++)
    {
        if (isPrime(i))
            cout << " " << i << " ";
    }

    return 0;
}

bool isPrime(int N)
{
for(int i=2; i<N ; i++)
    if (N % i==0)
        return false;
    else
        return true;
}
