#include <iostream>
using namespace std;
void secondMaxNumber(int array[4])
{
	int out,i,largest,second_max;
	largest=array[0];
	for(i=0;i<4;i++)
	{
			if(array[0]<array[i])
			array[0]=array[i];
			largest=array[0];
	}
	second_max=array[1];
	
	
	for(i=0;i<4;i++)
	{
		if((array[1]<array[i])&&(array[i]<largest))
		array[1]=array[i];
		second_max=array[1];
	}
	cout<<"Second Max num is "<<second_max;
}

int main() 
{
	int i,array[4];
	cout<<"4 numbers: ";
	
	for(i=0;i<4;i++)
	cin>>array[i];
	
	secondMaxNumber(array);
	
	
	return 0;
}
