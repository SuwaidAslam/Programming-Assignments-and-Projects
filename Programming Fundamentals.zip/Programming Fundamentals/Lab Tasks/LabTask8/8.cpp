#include <iostream>
using namespace std;
int s;
double ave(int arr[]);
int main() {
	int arr[s],i;
	cout<<"Enter size of array";
	cin>>s;
	cout<<"Avarage "<<ave(arr);
	return 0;
}

double ave(int arr[]){
	int sum=0,i,n;
	double result;
	cout<<"Enter array: ";
	for(i=0;i<s;i++)
	cin>>arr[i];
	for(i=0;i<s;i++)
	sum+=arr[i];

	
	return 	sum/s;
	
}
