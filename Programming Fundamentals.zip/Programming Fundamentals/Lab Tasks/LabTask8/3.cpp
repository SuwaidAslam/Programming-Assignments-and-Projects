#include <iostream>
using namespace std;
double power(double n, int p);
int main() {
	double n;
	int p=2;
	cout<<"Enter double: ";
	cin>>n;
	cout<<"Enter 0:  ";
	bool a;
	cin>>a;
	if(a==0)
	cout<<power(n,p);
	
	return 0;
}

double power(double n, int p){
	int i;
	double c=1;
	for(i=1;i<=p;i++)
	{
			c*=n;
	}
	return c;
}
