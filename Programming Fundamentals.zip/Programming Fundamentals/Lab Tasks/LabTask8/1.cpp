#include <iostream>
using namespace std;
int fact(int a);

int main() 
{
	int c,input;
	cout<<"Enter number: ";
	cin>>input;
	c = fact(input);
	cout<<"Factorial= "<<c;
	return 0;
}
int fact(int a){
	int i;
	for(i=a-1;i>=1;i--)
	{
		a*=i;
	}
	return a;
}
