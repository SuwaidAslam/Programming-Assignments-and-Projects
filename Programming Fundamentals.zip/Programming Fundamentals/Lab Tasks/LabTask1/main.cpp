#include <iostream>
using namespace std;
int main(){
    int a;
    cout<<"Input any number: ";
    cin>>a;
    if(a%2== 0){
    cout<<"This is an Even Number"<<endl;
    }
    else{
    cout<<"This is an odd Number"<<endl;
    }
    return 0;
}