//Take four numbers from the user to check the largest in them.
#include <iostream>
using namespace std;
int main(){
    int n1,n2,n3,n4;
    int max_n;
    cout<<"Enter 4 numbers: ";
    cin>>n1>>n2>>n3>>n4;
    //By Using ternary operator.
    max_n = (n1 > n2 && n1 > n3 && n1 > n4) ? n1 : ((n2 > n3 && n2 > n4) ?  n2 : (n3 > n4 ? n3 : n4));
    cout<<"Largest number is: "<<max_n<<endl<<endl;
    
    cout<<"---------------------------------------"<<endl<<endl;
    //By Using Nested if statements.
    if(n1>n2 && n1>n3 && n1>n4){
    	cout<<"Largest number is: "<<n1<<endl;
	}
	else{
        if(n2 > n3 && n2 > n4){
            cout<<"Largest number is: "<<n2<<endl;
        }
        else{
            if(n3 > n4){
                cout<<"Largest number is: "<<n3<<endl;
            }
            else{
                cout<<"Largest number is: "<<n4<<endl;
            }
        }
}
    
    return 0;
}
