 #include <iostream>
using namespace std;
int main() {
	int n; int out=1;
	cout<<"Enter Number of Rows: ";
	cin>>n;
	int i, j, k;
	for (i = 1; i <= n; i++) {
		// Print spaces 
		for (j =n; j >=i; j--) { 
			cout <<" "; 
		} 
		// Print numbers
		for (k =1;k<=i;k++) { 
				cout<<" "<<out;
				out++;
		} 
		// move to next row 
		cout << endl; 
	}
	return 0;
}
