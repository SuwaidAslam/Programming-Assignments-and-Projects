#include <iostream>
using namespace std;
int main() {
	int i,b,p,result=1;
	cout<<"Enter base and power respectively:";
	cin>>b>>p;
	for(i=p;i>=1;i--){
		
		result*=b;
	}
	
	cout<<b<<"^"<<p<<"= "<<result;
	return 0;
}
