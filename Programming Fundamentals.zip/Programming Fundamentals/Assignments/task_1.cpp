//Take a five digit number form the user and reverse and then display this number.
#include <iostream>
using namespace std;
int main(){
    int input,b,c,d,e,f,g,h,i,output;
    cout<<"Enter a 5 digit number: ";
    cin>>input;
    if(input>=10000 && input<=99999){
	b=input%10;   c=input/10;
	d=c%10;   e=c/10;
	f=e%10;   g=e/10;
	h=g%10;   i=g/10;
	output=b*10000+d*1000+f*100+h*10+i;
	cout<<"The reverse of "<<input<<" is "<<output<<endl;
    }
    else{
        cout<<"You have not entered a 5 digit number."<<endl;
    }
    return 0;
}
