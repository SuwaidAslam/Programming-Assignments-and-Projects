//2.Write a C program to check whether a year is leap year or not.
#include <iostream>
using namespace std;
int main() 
{
	int Y;
    cout << "Input a year: ";
    cin>>Y;

    if (Y%4==0)
    {
        if (Y%100==0)
        {
            if (Y%400==0)
                cout <<Y<< " is a leap year.";
            else
                cout <<Y<< " is not a leap year.";
        }
        else
            cout <<Y<< " is a leap year.";
    }
    else
        cout <<Y<< " is not a leap year.";
	return 0;
}
