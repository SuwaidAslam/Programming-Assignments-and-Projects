#include<iostream>
using namespace std;
const int size=3;
struct medicines
{
int id;
char name[30];
int price;
int quantity;
}med[size];
void input(medicines med[]);
void searchbyname(medicines med[]);
int main(){
input(med);
searchbyname(med);
return 0;
}
void input(medicines med[]){
	int a=1;
for(int i=0;i<size;i++){
	cout<<"Medicine #"<<a<<endl;
cout<<"Name of Medicine\n";
cin>>med[i].name;
cout<<"ID of Medicine\n";
cin>>med[i].id;
cout<<"Price of Medicine\n";
cin>>med[i].price;
cout<<"Quantity of Medicine\n";
cin>>med[i].quantity;
a++;
}
}
void searchbyname(medicines med[]){
string tempname;
cout<<"Enter name of the medicine to search: ";
cin>>tempname;
for(int i=0;i<size;i++){
if(tempname==med[i].name){
cout<<"Name of Medicine: "<<med[i].name<<endl;
cout<<"ID of Medicine: "<<med[i].id<<endl;
cout<<"Price of Medicine: "<<med[i].price<<endl;
}
}
}
