/*Write a cpp programe which asks the following options from the user to choose,
*Write M to find if the value in a variable is divisible by 8 or not;
*Enter N to find largest number betweet three numbers;*/
#include <iostream>
using namespace std;
int main() {
	char ch; 
	cout<<"Enter M to find if the number is divisible by 8 OR Enter N to find largest number between three numbers.";
	cin>>ch;
	switch(ch){
		case 'M': int n; cout<<"Enter an integer: "; cin>>n;
		if(n%8==0){
			cout<<"Is Divisible"<<endl;
		}
		else{
			cout<<"Not Divisible"<<endl;
		}
		break;
		case 'N': int a,b,c; cout<<"Enter three numbers: "; cin>>a>>b>>c;
		if((a>=b) && (a>=c) )
		   cout<<"Largest Number: "<<a;
		else if((b>=a) && (b>=c))
		   cout<<"Largest Number: "<<b;
		else
		   cout<<"Largest Number: "<<c;
		break;
	}
	return 0;
}
