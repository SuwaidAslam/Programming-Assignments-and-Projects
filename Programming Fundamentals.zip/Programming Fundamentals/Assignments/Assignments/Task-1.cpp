//1.Write a C program to check whether a number is divisible by 5 and 11 or not.
#include<iostream>
using namespace std;
int main(){
	int num;
	cout<<"Input a number:";
	cin>>num;
	if(num%5==0)
	cout<<num<<" is divisible by 5.";
	else if(num%11==0)
	cout<<num<<" is divisible by 11.";
	else
	cout<<num<<" is not divisible by either 5 or 11";
	return 0;
}
