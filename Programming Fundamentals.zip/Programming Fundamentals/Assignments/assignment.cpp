#include <iostream>
using namespace std;
const int size=20;
struct student{
	int rollnum;
	char name[30];
	int age;
	char gender[10];
	float phy_marks,chem_marks,bio_marks;
	
}s[size];
void input(student *p);
void print(student *ptr);
int main() {
	student *ptr=s;
	input(ptr);
	print(ptr);
	return 0;
}

void input(student *ptr){
	int count=1;
	for(int i=0;i<size;i++){
		cout<<"\t\nStudent#"<<count;
		cout<<"\nEnter RollNum of Student: ";
		cin>>ptr->rollnum;
		cout<<"\nEnter Name of Student: ";
		cin>>ptr->name;
		cout<<"\nEnter age of Student: ";
		cin>>ptr->age;
		cout<<"\nEnter gender of Student: ";
		cin>>ptr->gender;
		cout<<"\nEnter Marks in Physics: ";
		cin>>ptr->phy_marks;
		cout<<"\nEnter Marks in Chemistry: ";
		cin>>ptr->chem_marks;
		cout<<"\nEnter Marks in Biology: ";
		cin>>ptr->bio_marks;
		count++;
		ptr++;
	}
}

void print(student *ptr){
	cout<<"\t\nList of students who have passed in 2 subjects.\n\n";
		int count=1;
	for(int i=0;i<size;i++){
		if((ptr->phy_marks>=33 && ptr->chem_marks >=33 && ptr->bio_marks <33 ) || (ptr->phy_marks >=33 && ptr->bio_marks>=33 && ptr->chem_marks<33 ) || (ptr->chem_marks>=33 && ptr->bio_marks>=33 && ptr->phy_marks<33 ))
		{
		cout<<"\t\nStudent#"<<count;
		cout<<"\n\nRollNum of Student: ";
		cout<<ptr->rollnum;
		cout<<"\n\nName of Student: ";
		cout<<ptr->name;
		count++;
	   }
	ptr++;
}
}
