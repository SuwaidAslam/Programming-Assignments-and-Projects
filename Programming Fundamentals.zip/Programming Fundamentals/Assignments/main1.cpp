#include <iostream>
using namespace std;
int main() {
	int n;
	cout<<"Enter Number of Rows: ";
	cin>>n;
	int row,space, star;
	//For Rows
	for(row=1;row<=n;row++){
		//For spaces(column)
		for(space=1;space<row;space++){
			cout<<" ";
		}
		//For display(column)
		for(star=n;star>=row;star--){
			cout<<"*";
		}
		cout<<endl;
	}
	return 0;
}
