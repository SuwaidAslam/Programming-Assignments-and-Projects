#include <iostream>
using namespace std;
int main() {
	int r,c;
	cout<<"Enter rows and columns: ";
	cin>>r>>c;
	int a[r][c], b[r][c], i, j,multi[r][j];
	cout<<"Enter elements of matrix A: ";
    for(i = 0; i < r; ++i)
	{
    for(j = 0; j < c; ++j)
    {
        cin >> a[i][j];
    }
}
cout<<"Enter elements of matrix B: ";
    for(i = 0; i < r; ++i)
	{
    for(j = 0; j < c; ++j)
    {
        cin >> b[i][j];
    }
}
    cout<<"Entered Matrix A: " << endl;
    for(i = 0; i < r; ++i){
        for(j = 0; j < c; ++j)
        {
            cout <<" "<<a[i][j];
        }
        cout<<endl;
    }
    
     cout<<"Entered Matrix B: " << endl;
    for(i = 0; i < r; ++i){
        for(j = 0; j < c; ++j)
        {
            cout <<" "<<b[i][j];
        }
        cout<<endl;
    }
    cout<<endl;
    int sum=0,k;
    for(i = 0; i< r; ++i){
        for(j = 0; j < c; ++j)
        {
        	for(k=0;k<c;k++){
        			sum+=a[i][k]*b[k][j];
			}
			multi[i][j]=sum;
			sum=0;
			 
		}	
		
		cout<<endl;
	}
	cout<<"Product of A and B is: "<<endl;
	for(i = 0; i < r; ++i){
        for(j = 0; j < c; ++j)
        {
            cout <<" "<<multi[i][j]<<" ";
        }
        cout<<endl;
    }
		
		
    return 0;
}
