#include <iostream>
using namespace std;
int main() {
	int i,j,k,n;
	cout<<"Enter number of rows: ";
	cin>>n;
	for(i=1;i<=n;i++){
		//for spaces
		for(j=n;j>=i;j--){
			cout<<" ";
		}
		//for print
		for(k=2;k<=i*3;k++){
			cout<<" "<<"*";
		}
		cout<<endl;
	}
	
	for(i=n+2;i>=1;i--){
		//for spaces
	for(j=n+2;j>=i;j--){
			cout<<" ";
		}
		//for print
	for(k=5;k<=i*3;k++){
			cout<<" "<<"*";
		}
		cout<<endl;
	}
	return 0;
}
