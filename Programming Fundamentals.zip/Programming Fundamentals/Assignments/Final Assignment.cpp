#include <iostream>
#include <fstream>
#include <string>
using namespace std;
struct store
{
	int id;
	string name;
	int quantity;
	int price;
	float discount;
}product[3];
void insert(store product[]);
void display(store product[]);
void discountProduct(store product[]);
void sumOfPrice(store product[]);
int main()
{
	cout<<"\t------Enter data in the file------\n";
	cout<<"Input 'I' for insert : Input 'D' for Display : Input 'S' for sum : Input 'P' for discount prices and Input 'E' to exit.";
	char input;
	cout<<endl;
	cin>>input;
	switch(input)
	{
		case 'I':
			insert(product);
			main();
			break;
		case 'D':
			display(product);
			main();
			break;
		case 'S':
			sumOfPrice(product);
			main();
			break;
		case 'P':
			discountProduct(product);
			main();
			break;
		case 'E':
			break;
	}
	
return 0;
}

void insert(store product[])
{
	ofstream file;
	file.open("deptstore.txt",ios::out);
	int count=1;
	for(int i=0;i<3;i++)
	{
		cout<<"\tEnter info of Products# "<<count<<endl;
		cout<<"Enter the ID:\n";
		cin>>product[i].id;
		file<<product[i].id<<" ";
		cout<<"Enter the Name:\n";
		cin>>product[i].name;
		file<<product[i].name<<" ";
		cout<<"Enter the Quantity:\n";
		cin>>product[i].quantity;
		file<<product[i].quantity<<" ";
		cout<<"Enter the Price:\n";
		cin>>product[i].price;
		file<<product[i].price<<" ";
		cout<<"Enter the Discount:\n";
		cin>>product[i].discount;
		file<<product[i].discount<<endl;
		count++;
}
	file.close();
}

void display(store product[])
{
	ifstream file2;
	file2.open("deptstore.txt",ios::in);
	int i=0;
	bool b;
     while (file2>>product[i].id>>product[i].name>>product[i].quantity>>product[i].price>>product[i].discount)
	 {
       if(product[i].name[0]=='q')
	   {
	   cout<<"Name of the Product is:\n";
	   cout<<product[i].name;
	   }
	   else
	   cout<<"Product not found";
	   i++;
     }
     
    file2.close();
}

void discountProduct(store product[])
{
	ifstream file3;
	file3.open("deptstore.txt",ios::in);
	int i=0;
     while (file3>>product[i].id>>product[i].name>>product[i].quantity>>product[i].price>>product[i].discount)
	 {
       if(product[i].discount==50)
	   {
	   	cout<<"Name of the Product is:\n";
		cout<<product[i].name;
	   }
	   i++;
     }
     file3.close();
}

void sumOfPrice(store product[])
{
	ifstream file4;
	file4.open("deptstore.txt",ios::in);
	int i=0,sum=0;
     while (file4>>product[i].id>>product[i].name>>product[i].quantity>>product[i].price>>product[i].discount)
	 {
	   	sum+=product[i].price;
	   i++;
     }
     cout<<"Sum of all the prices is:\n";
     cout<<sum;
     file4.close();
}


	
	

