#include <iostream>
using namespace std;
int main() 
{
	int CP,SP,profit,loss;
	cout<<"Enter cost price: ";
	cin>>CP;
	cout<<"Enter selling price: ";
	cin>>SP;
	profit=SP-CP;
	loss=CP-SP;
	if(profit>0)
	cout<<"Profit is: "<<profit;
	else if(profit<0)
	cout<<"Loss is: "<<loss;
	else if(profit==0)
	cout<<"Neither profit nor loss.";
	return 0;
}
