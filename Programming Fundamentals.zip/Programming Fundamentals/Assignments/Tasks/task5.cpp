#include <iostream>
using namespace std;
int main() 
{
	int num=0,next;
	for(int i=0;i<=30;i++)
	{
		if(num>2)
		{
			next=num+num-1;
			
		}
		num++;
	}
	
	return 0;
}
