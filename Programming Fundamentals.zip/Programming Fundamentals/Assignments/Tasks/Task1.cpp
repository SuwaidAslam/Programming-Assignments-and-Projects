#include <iostream>
using namespace std;
int main() {
	int week;
	cout<<"Enter week number: ";
	cin>>week;
	int days;
	days=week*7;
	cout<<"Days are "<<days;
	return 0;
}
