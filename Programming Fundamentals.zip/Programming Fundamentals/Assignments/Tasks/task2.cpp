#include <iostream>
using namespace std;
int main() 
{
	int month;
	cout<<"Input month number: ";
	cin>>month;
	int Jan=31,Feb=28,Mar=31,Apr=30,May=31,June=30,July=31,Aug=31,Sep=30,Oct=31,Nov=30,Dec=31;
	switch(month)
	{
		case 1: cout<<"In this month number of days are "<<Jan;
		break;
		case 2: cout<<"In this month number of days are "<<Feb;
		break;
		case 3: cout<<"In this month number of days are "<<Mar;
		break;
		case 4: cout<<"In this month number of days are "<<Apr;
		break;
		case 5: cout<<"In this month number of days are "<<May;
		break;
		case 6: cout<<"In this month number of days are "<<June;
		break;
		case 7: cout<<"In this month number of days are "<<July;
		break;
		case 8: cout<<"In this month number of days are "<<Aug;
		break;
		case 9: cout<<"In this month number of days are "<<Sep;
		break;
		case 10: cout<<"In this month number of days are "<<Oct;
		break;
		case 11: cout<<"In this month number of days are "<<Nov;
		break;
		case 12: cout<<"In this month number of days are "<<Dec;
		break;
	}
	return 0;
}
