#include <iostream>
using namespace std;
struct student
{
	float phy;
	float chem;
	float bio;
	float math;
	float comp;
}stu_marks;
int main() 
{
	cout<<"Input Physics marks out of 100: ";
	cin>>stu_marks.phy;
	cout<<"Input Chemistry marks out of 100: ";
	cin>>stu_marks.chem;
	cout<<"Input Biology marks out of 100: ";
	cin>>stu_marks.bio;
	cout<<"Input Mathematics marks out of 100: ";
	cin>>stu_marks.math;
	cout<<"Input Computer marks out of 100: ";
	cin>>stu_marks.comp;
	
	float total=stu_marks.phy+stu_marks.chem+stu_marks.bio+stu_marks.math+stu_marks.comp;
	float percent=(total/500)*100;
	if(percent>=90)
	cout<<"Grade is A.";
	else if(percent>=80)
	cout<<"Grade is B.";
	else if(percent>=70)
	cout<<"Grade is C.";
	else if(percent>=60)
	cout<<"Grade is D.";
	else if(percent>=40)
	cout<<"Grade is E.";
	else if(percent<40)
	cout<<"Grade is F.";
	return 0;
}
