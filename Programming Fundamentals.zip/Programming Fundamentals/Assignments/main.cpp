#include <iostream>
using namespace std;
int main() {
	int n;
	cout<<"Enter Number of Rows: ";
	cin>>n;
	int row,space,star;
	//For Rows
	for(row=1;row<=n;row++){
		//For Stars(column)
		for(star=1;star<=row;star++){
			cout<<"*";
		}
		//For Spaces(column)
		for(space=n;space>row;space--){
			cout<<" ";
		}
		cout<<endl;
	}
	return 0;
}
