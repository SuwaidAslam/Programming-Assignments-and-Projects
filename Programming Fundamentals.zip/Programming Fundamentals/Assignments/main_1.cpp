//Calculate Salary.
#include <iostream>
using namespace std;
int main(){
    int salary;
    cout<<"Input your Salary: ";
    cin>>salary;
    if(salary<=50000){
        int tax;
        tax=salary*0.1;
        cout<<"Your Final salary is: RS. "<<(salary-tax)<<endl;
    }
    else if(salary>50000 && salary<=60000){
        int tax;
        tax=salary*0.2;
        cout<<"Your Final salary is: RS. "<<(salary-tax)<<endl;
    }
    else if(salary>60000){
        int tax;
        tax=salary*0.3;
        cout<<"Your Final salary is: RS. "<<(salary-tax)<<endl;
    }
    return 0;
}
