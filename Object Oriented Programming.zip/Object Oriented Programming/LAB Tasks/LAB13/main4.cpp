#include <iostream>
using namespace std;
#include <typeinfo>

template <class T>
void Type(T a){
	if(*(typeid(a).name()) == 'i')
		cout<<"Integer"<<endl;
	else if(*((char *)typeid(a).name()) == 'd')
	cout<<"Double"<<endl;
	else if(*((char *)typeid(a).name()) == 'c')
	cout<<"Character"<<endl;
	
}
int main() {
	Type(2);
	Type('a');
	Type(2.5);
	return 0;
}
