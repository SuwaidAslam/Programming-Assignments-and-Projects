#include <iostream>
using namespace std;

template <class T>
T Max(T a, T b){
	return (a>b?a:b);
}

int main() {
	char a,b;
	cout<<"Enter Two Characters: ";
	cin>>a>>b;
	cout<<"Max: "<<Max(a,b)<<endl;
	
	int c,d;
	cout<<"Enter Two integers: ";
	cin>>c>>d;
	cout<<"Max: "<<Max(c,d)<<endl;
	
	float e,f;
	cout<<"Enter Two float integers: ";
	cin>>e>>f;
	cout<<"Max: "<<Max(e,f)<<endl;
	return 0;
}
