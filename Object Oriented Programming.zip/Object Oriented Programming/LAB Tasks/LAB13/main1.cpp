#include <iostream>
using namespace std;

class ZooAnimal
 {
 private:
 string name;
 int cageNumber;
 int weightDate;
 int weight;
 static int oldestWeightDate;
 public:
 ZooAnimal (string s, int i, int e, int o) : name(s), cageNumber(i), weightDate(e)
 ,weight(o){}; // constructor function
 void changeWeight (int pounds);
 string reptName ();
 int reptWeight ();
 int daysSinceLastWeighed (int today);
 static void changeOldestWeightDate(int);
 };
 
int ZooAnimal::oldestWeightDate = 0;
void ZooAnimal::changeOldestWeightDate(int a){
	oldestWeightDate = a;	
}

int main() {
	ZooAnimal zoo_animal("Zebra", 22, 24, 150);
	zoo_animal.changeOldestWeightDate(25);
	return 0;
}
