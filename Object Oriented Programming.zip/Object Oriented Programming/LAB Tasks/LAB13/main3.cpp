#include <iostream>
using namespace std;
template <class T>
class Array{
	private:	
		T *a;
		int n;
	public:
		void getdata(){
			cout<<"Enter How many Numbers: ";
			cin>>n;
			a = new T[n];
			for(int i=0; i<n ; i++){
				cout<<"Enter a number: ";
				cin>>a[i];
			}
		}
		void putdata(){
			for(int i=0;i<n;i++){
				cout<<a[i]<<" ";
			}
		}
		void sort(){
			T k;
			for(int i=0; i<n;i++){
				for(int j=0 ; j<n; j++){
					if(a[i]>a[j]){
						k =a[i];
						a[i]=a[j];
						a[j]=k;
					}
				}
			}
		}
};
int main() {
	Array<int> a;
	a.getdata();
	a.sort();
	a.putdata();
	
	Array<flaot> b;
	b.getdata();
	b.sort();
	b.putdata();
	return 0;
}
