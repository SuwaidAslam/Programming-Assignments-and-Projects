#include <iostream>
using namespace std;
class Car{
	public:
	int gear;
	int breakk;
	char model;
	Car(){
	gear = 5;
	breakk = 10;
	model = 'm';
	}
	void display(){
		cout<<gear<<endl;
		cout<<breakk<<endl;
		cout<<model;
	}
};
int main(){
	Car car1;
	cout<<"Enter gear value: ";
	cin>>car1.gear;
	cout<<"Enter breakk value: ";
	cin>>car1.breakk;
	cout<<"Enter model : ";
	cin>>car1.model;
	car1.display();
	return 0;
}
