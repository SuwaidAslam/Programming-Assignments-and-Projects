#include <iostream>
using namespace std;
void ref(int& , int&);
int main() {
	int x , y;
	cout<<"Enter Value of x: ";
	cin>>x;
	cout<<"Enter Value of y: ";
	cin>>y;
	swap(x,y);
	cout<<"x = "<<x<<endl;
	cout<<"y = "<<y;
	return 0;
}
void swap(int &x , int &y){
	int z=0;
	z = x;
	x = y;
	y = z;
}
