#include <iostream>
using namespace std;
inline int max(int a, int b, int c);
int main() {
	int a,b,c;
	cout<<"Enter a,b,c: ";
	cin>>a>>b>>c;
	int maximum = max(a,b,c);
	cout<<"The largest number is: "<<maximum;
}
inline int max(int a, int b, int c){
	return (a>b) ? ((a>c)? a : c): ((b>a && b>c) ? b : c);
}
