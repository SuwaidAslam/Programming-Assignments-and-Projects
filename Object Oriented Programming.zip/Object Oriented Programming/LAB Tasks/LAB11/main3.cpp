#include<iostream>
using namespace std;
class Mammals{
public:
	void display(){
		 cout<<"I am Mammal."<<endl;
	}

};
class MarineAnimals{
   public:
  void display(){ 
  cout<<"I am Marineanimal."<<endl;
  }
};

class BlueWhale :public Mammals, public MarineAnimals{
	public:
		void display(){
		cout<<"I belong to both Mammal and MarineAnimal."<<endl;}
};

int main()
{
    Mammals am;
    MarineAnimals mran;
    BlueWhale bw;
    am.display();
    mran.display();
    bw.display();
    Mammals *obj;
    BlueWhale obj2;
    obj=&obj2;
	obj->display();

   return 0;
}

