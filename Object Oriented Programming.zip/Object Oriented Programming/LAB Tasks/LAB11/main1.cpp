#include <iostream>
#include <string>
#include <stdlib.h>
using namespace std;
class Marks {
public:
	int rollNumber;
	string name;
	int marks;
	Marks(){GenerateRollNum();}
	void GenerateRollNum(){rollNumber = rand() % (( 1000 + 1 ) - 10);}
	
};

class Physics : public Marks {
	int sum(){
		return  marks;
	}
};


class Chemistry : public Marks {
	public:
};


class Mathematics : public Marks {
	public:
};

int main(){
;	int num_of_std,stu_cnt=0;
	cout<<"Enter Number of Students:";
	cin>>num_of_std;
	Physics* phy_objs = new Physics[num_of_std];
	Chemistry* chem_objs = new Chemistry[num_of_std];
	Mathematics* math_objs = new Mathematics[num_of_std];

	for(int i=0; i<num_of_std; i++){
		stu_cnt++;
		cout<<"\n\t\t\tStudent#"<<stu_cnt<<"\t\t\t\n";
		cout<<"Student Name: ";
		cin>>phy_objs[i].name;
		math_objs[i].name = chem_objs[i].name = phy_objs[i].name;
		cout<<"Physics Marks: ";
		cin>>phy_objs[i].marks;
		cout<<"\nChemistry Marks: ";
		cin>>chem_objs[i].marks;
		cout<<"\nMathematics Marks: ";
		cin>>math_objs[i].marks;
	}
	stu_cnt= 0;
	int phy_sum=0, chem_sum=0, math_sum=0;
	for(int i=0; i<num_of_std; i++){
		stu_cnt++;
		cout<<"\n\t\t\tStudent#"<<stu_cnt<<"\t\t\t\n";
		cout<<"Student Name: ";
		cout<<phy_objs[i].name;
		cout<<"\nStudent Roll Number: ";
		cout<<phy_objs[i].rollNumber;
		cout<<"\nTotal Marks: ";
		cout<<phy_objs[i].marks + chem_objs[i].marks + math_objs[i].marks;
		phy_sum += phy_objs[i].marks;
		chem_sum += chem_objs[i].marks;
		math_sum += math_objs[i].marks;
	}
	cout<<"\n\t\t----------------------\t\t\n";
	cout<<"\nAverage Physics Marks: ";
	cout<<phy_sum/num_of_std;
	cout<<"\nAverage Chemistry Marks: ";
	cout<<chem_sum/num_of_std;
	cout<<"\nAverage Mathematics Marks: ";
	cout<<math_sum/num_of_std;
	delete[] math_objs;
	delete[] chem_objs;
	delete[] phy_objs;
return 0;
}
