	#include <iostream>
using namespace std;
class Fruit{
	public:
		static int num_of_fruits;
		Fruit(){
			num_of_fruits++;
		}
		~Fruit(){
			num_of_fruits--;
		}
};
class Apple : public Fruit{
	public:
	static int num_of_apples;
	  Apple():Fruit()
	  {
	    num_of_apples++;
	  }
	  ~Apple()
	  {
	    num_of_apples--;
	  }
};
class Mangos : public Fruit{
	public:
	  static int num_of_mangos;
	  Mangos():Fruit(){
	    num_of_mangos++;
	  }
	  ~Mangos(){
	    num_of_mangos--;
	  }

};
class Basket: public Apple, public Mangos{
	public:
		static int num_of_apples;
		static int num_of_mangos;
};

int Fruit::num_of_fruits = 0;
int Apple::num_of_apples = 0;
int Mangos::num_of_mangos = 0;

int main() {
  int n;
  cout<<"Enter Number of Apples: ";
  cin>>n;
  Apple* apples = new Apple[n];
  cout<<"Enter Number of Mangoes: ";
  cin>>n;
  Mangos* mangos = new Mangos[n]; 
  cout << "Total number of fruits in the Basket: " << Basket::num_of_fruits << endl;
  cout << "Number of apples: " << Apple::num_of_apples << endl;
  cout << "Number of mangoes: " << Mangos::num_of_mangos << endl;
  delete[] mangos;
  delete[] apples;
  return 0;
}
