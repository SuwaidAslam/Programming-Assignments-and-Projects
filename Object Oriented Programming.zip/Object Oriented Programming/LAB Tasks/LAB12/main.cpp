#include <iostream>
#include <cmath>
#include<conio.h>
using namespace std;
class Shape{
	public:
		int x,y;
		Shape(){
		}
		Shape(int x1, int y1) : x(x1), y(y1){
		}
		virtual void display_area()=0;
};
class Triangle: public Shape{
	int z;
	public:
		Triangle(){
			cout<<"Enter x:";
			cin>>x;
			cout<<"Enter Y:";
			cin>>y;
			cout<<"Enter Z:";
			cin>>z;
		}
		Triangle(int x1, int y1, int z1): Shape(x1,y1){
			z = z1;
		}
		void display_area(){
			double p = (x+y+z)/2;
			double area = sqrt(p*(p-x)*(p-y)*(p-z));
			cout<<"Triagle Area: "<<area<<endl;
		}
		
};
class Rectangle: public Shape{
	public:
		Rectangle(){
			cout<<"Enter x:";
			cin>>x;
			cout<<"Enter Y:";
			cin>>y;
		}
		Rectangle(int x1,int y1) : Shape(x1,y1){
		}
		void display_area(){
			double area = x*y;
			cout<<"Area of Rectangle: "<<area<<endl;
		}
};
int main() {
	int option = -1;
	Shape *shape;
	while(option!=0){
		cout<<"1. Area of Triangle:"<<endl;
		cout<<"2. Area of Rectangle:"<<endl;
		cout<<"3. Press 0 to exit"<<endl;
		cout<<"Enter Option:";
		cin>>option;
		if(option==1){
			shape = new Triangle;
			shape->display_area();
			delete shape;
		}
		if(option==2){
			shape = new Rectangle;
			shape->display_area();
			delete shape;
		}
		getch();
		system("CLS");
	}
	return 0;
}
