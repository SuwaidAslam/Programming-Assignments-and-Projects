#include<iostream>
using namespace std;
class Mammals{
public:
	virtual void display(){
		 cout<<"I am Mammal."<<endl;
	}
};
class MarineAnimals : public Mammals{
   public:
  void display(){ 
  cout<<"I am Marineanimal."<<endl;
  }
};

class BlueWhale :public virtual Mammals{
	public:
		void display(){
		cout<<"I belong to both Mammal and MarineAnimal."<<endl;
		}
};

int main()
{
    Mammals *mammal;
	mammal = new MarineAnimals;
	mammal->display();
	delete mammal;
	mammal = new BlueWhale;
	mammal->display();
   return 0;
}

