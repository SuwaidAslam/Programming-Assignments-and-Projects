#include <iostream>
#include <string>
using namespace std;
class Matrix{
	private:
		int a[100][100] , m,n;
	public:
		Matrix() : m(0),n(0){}
		Matrix(Matrix &t){
			for(int i=0;i<m;i++){
				for(int j=0;j<n;j++){
					a[i][j] = t.a[i][j];
				}
			}
		}
		void getdata(){
			int i,j;
			cout<<"Enter Matrix Size m by n: ";
			cin>>m>>n;
			for(int i=0;i<m;i++){
				for(int j=0;j<n;j++){
					cout<<"Enter a num:";
					cin>>a[i][j];
				}
			}
		}
		void show(Matrix &tem){
			cout<<"Additon of Two Matrix is:\n";
			for(int i=0;i<m;i++){
				for(int j=0;j<n;j++){
					cout<<tem.a[i][j]<<" ";
				}
				cout<<endl;
			}
		}
		Matrix operator + (Matrix &b){
			Matrix temp;
			for(int i=0;i<m;i++){
				for(int j=0;j<n;j++){
					temp.a[i][j] = a[i][j] + b.a[i][j];
				}
			}
			return temp;
		}
};
int main() {
	Matrix a,b,temp2;
	cout<<"Enter Values of First Vector:\n";
	a.getdata();
	cout<<"Enter Values of Second Vector:\n";
	b.getdata();
	temp2 = a + b;
	a.show(temp2);
	return 0;
}
