#include <iostream>
#include <cstring>
using namespace std;
class Student{
	protected:
		int roll_num;
		char nm[30];
	public:
		void get_n(int a, char *n){
			roll_num = a;
			strcpy(nm,n);
		}
		void put_n(){
			cout<<"Roll Num: "<<roll_num<<endl;
			cout<<"Name: "<<nm<<endl;
		}
};
class Test : public Student{
	protected:
		int part1, part2;
	public:
		void get_m(int x, int y){
			part1 = x;
			part2 = y;
		}
		void put_m(){
			cout<<"Obtained Marks: "<<endl;
			cout<<"Part1: "<<part1<<endl;
			cout<<"Part2: "<<part2<<endl;
		}
		void put_n(){
			Student::put_n();
		}
		void get_n(int a, char n[30]){
			Student::get_n(a , n);
		}
};
class Sports : public Student{
	protected:
		int score;
	public:
		void get_s(int a){
			score = a;
		}
		void put_s(){
			cout<<"Score: "<<score<<endl;
		}
};
class Result : public Test, public Sports{
	private:
		int total;
		float avg;
	public:
		void show(){
			total = part1 + part2 + score;
			avg = float(total / 3);
			Test::put_n();
			Test::put_m();
			Sports::put_s();
			cout<<"Total: "<<total<<endl;
			cout<<"Average: "<<avg<<endl;
		}
};
int main() {
	Result result;
	result.Test::get_n(12534, (char *)"Suwaid");
	result.get_m(50,90);
	result.get_s(30);
	result.show();
	return 0;
}
