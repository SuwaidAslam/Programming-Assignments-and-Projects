#include <iostream>
#include <string>
#include <fstream>
using namespace std;
int main() {
	int a=0,b=0;
	char c;
	fstream read_file;
	read_file.open("file1.txt", ios::in);
	while(read_file){
		read_file>>a>>c>>b;
	}
	read_file.close();
	fstream write_file;
	write_file.open("result.txt",ios::out);
	int result = a+b;
	write_file<<result;
	write_file.close();
	return 0;
}
