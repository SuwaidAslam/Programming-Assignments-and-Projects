#include <iostream>
#include <string>
#include <fstream>
using namespace std;
int main() {
	int a[] = {1,2,3,8};
	int b[10];
	char *ptr = reinterpret_cast<char *>(&a);
	fstream File("file.dat",ios::out | ios::in | ios::binary);
	File.write(ptr,sizeof(a));
	File.seekg(0L,ios::beg);
	File.read(reinterpret_cast<char *>(&b),sizeof(b));
	File.close();
	ofstream write("new.txt",ios::out);
	int i=0;
	while(b[i]){
		write<<b[i];
		i++;
	}
	write.close();
	return 0;
}
