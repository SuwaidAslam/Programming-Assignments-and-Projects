#include <iostream>
using namespace std;
class Area{
	public:
		float area(float i, float b){
			return i*b;
		}
};
class Perimeter{
	public:
		float peri(float i, float b){
			return 2*(i+b);
		}
};
class Rectangle : public Area, public Perimeter{
	private:
		float length;
		float breadth;
	public:
		void get_data(){
			cout<<"Enter length and breadth: ";
			cin>>length>>breadth;
		}
		void calc(){
			cout<<"Area: "<<area(length,breadth)<<endl;
			cout<<"Perimeter: "<<peri(length,breadth)<<endl;
		}
};
int main() {
	Rectangle rec;
	rec.get_data();
	rec.calc();
	return 0;
}
