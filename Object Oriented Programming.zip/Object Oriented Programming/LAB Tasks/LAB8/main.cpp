#include <iostream>
#include <string>
using namespace std;
class CAR{
	protected:
		string color;
		int year;
	public:
		CAR() : color("Red"), year(2020){}
		CAR(string clr,int yr) : color(clr), year(yr){}
		int Breaks(int i){
			return i;
		}
		int Gear(int i){
			return i;
		}
};
class Suzuk : public CAR{
	protected:
		string Model;
	public:
		Suzuk(): Model("Dream"){}
		Suzuk(string mdl) : Model(mdl){
		}
		void display(){
			cout<<"Model: "<<Model<<endl;
			cout<<"Color: "<<color<<endl;
			cout<<"Year: "<<year<<endl;
			cout<<"Gears: "<<Gear(5)<<endl;
			cout<<"Breaks: "<<Breaks(1)<<endl;
			
		}
};
class Toyota : public CAR{
	private:
		string Model;
	public:
		Toyota(): Model(""){}
		Toyota(string mdl) : Model(mdl){
		}
		void display(){
			cout<<"Model: "<<Model<<endl;
			cout<<"Color: "<<color<<endl;
			cout<<"Year: "<<year<<endl;
			cout<<"Gears: "<<Gear(5)<<endl;
			cout<<"Breaks: "<<Breaks(1)<<endl;
		}
};
class Bike : public Suzuk{
	private:
		string Model;
	public:
		Bike() : Model("Prider"){
		}
};
int main() {
	CAR car("Red",2020);
	Suzuk alto("Suzuki Alto");
	Toyota corolla("Toyota Corolla");
	alto.display();
	corolla.display();
	Bike bike;
	bike.display();
	return 0;
}
