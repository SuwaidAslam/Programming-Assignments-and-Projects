#include <iostream>
#include <string>
using namespace std;
const int size =100;
class String{
	private:
		char *str;
		char str_arr[size];
	public:
		String() : str(NULL){
		}
		String(char *s) : str(s){
			int i=0;
			while(*str){
				str_arr[i] = *str;
				str++;
				i++;
				}
		}
		string operator + (const String &b) const{
			string temp;
			int i = 0;
			while(str_arr[i]){
				temp += str_arr[i];
				i++;
			}
			i = 0;
			while(b.str_arr[i]){
				temp += b.str_arr[i];
				i++;
			}
			return temp;
		}
		
		bool operator == (const String &b) const{
			int i = 0;
			while(str_arr[i] == b.str_arr[i]){
				if(str_arr[i] == '\0' && b.str_arr[i] == '\0'){
					return true;
				}
				i++;
			}
			return false;
		}
};
int main() {
	char s1[100];
	char s2[100];
	cout<<"Input First String: ";
	cin.getline(s1,sizeof(s1));
	cout<<"Input Second String: ";
	cin.getline(s2,sizeof(s2));
	String str1(s1) , str2(s2);
	cout<<"\nConcatenated String is: "<<str1 + str2;
	if(str1 == str2){
		cout<<"\nEntered strings are matched.";
	}
	else{	
		cout<<"\nEntered strings are not matched.";
	}
	return 0;
}
