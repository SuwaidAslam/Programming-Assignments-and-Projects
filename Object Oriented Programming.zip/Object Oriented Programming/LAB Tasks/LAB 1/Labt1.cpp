#include <iostream>
using namespace std;
inline int max(int a=1, int b=10);
int main() {
	int a,b;
	cout<<"Enter Two Numbers: ";
	cin>>a;
	cin>>b;
	int maximum = max(a,b);
	cout<<"Maximum number is: "<<maximum;
	return 0;
}

inline int max(int a, int b){
	return (a>b)? a: b;
}
