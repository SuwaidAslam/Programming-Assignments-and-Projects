#include <iostream>
#include <string>
using namespace std;
struct var1{
	int gear;
	int breakk;
	char model;
};
struct var2{
	int gear;
	int breakk;
	char model;
};
struct var3{
	int gear;
	int breakk;
	char model;
};
int main() {
	var1 variable1;
	var2 variable2;
	var3 variable3;
	cout<<"Enter the values of variable1: ";
	cin>>variable1.gear;
	cin>>variable1.model;
	cin>>variable1.breakk;
	cout<<"Enter the values of variable2:\n ";
	cin>>variable2.gear;
	cin>>variable2.model;
	cin>>variable2.breakk;
	cout<<"Enter the values of variable3:\n ";
	cin>>variable3.gear;
	cin>>variable3.model;
	cin>>variable3.breakk;
	return 0;
}
