#include <iostream>
#include <string>
using namespace std;
inline void ref(int& , int&);
int main() {
	int a ,b;
	cout<<"Enter Value of a: ";
	cin>>a;
	cout<<"Enter Value of b: ";
	cin>>b;
	ref(a,b);
	cout<<"a = "<<a<<endl;
	cout<<"b = "<<b;
	return 0;
}
inline void ref(int &a , int &b){
	int t=0; t = a; a = b; b = t;
}
