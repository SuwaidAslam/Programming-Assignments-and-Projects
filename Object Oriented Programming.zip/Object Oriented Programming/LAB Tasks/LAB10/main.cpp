#include <iostream>
#include <cmath>
using namespace std;
class Shape{
	protected:
		double x,y;
		void getdata(){
			cout<<"Enter Value of X:";
			cin>>x;
			cout<<"Enter Value of Y:";
			cin>>y;
		}
		void display_area(){
		}
		void display_data_members(){
		}
};
class Triangle: private Shape{
	private:
		double z;
	public:
		void getdata(){
			Shape::getdata();
			cout<<"Enter Value of Z:";
			cin>>z;
		}
		void display_area(){
			double p = (x+y+z)/2;
			double area = sqrt(p*(p-x)*(p-y)*(p-z));
			cout<<"Area of Triangle is:"<<area;
		}
		void display_data_members(){
			cout<<"X = "<<x<<endl;
			cout<<"Y = "<<y<<endl;
			cout<<"Z = "<<z<<endl;
		}
};
class Rectangle: private Shape{
	public:
		void getdata(){
			Shape::getdata();
		}
		void display_area(){
			double area = x*y;
			cout<<"Area of Rectangle is:"<<area;
		}
		void display_data_members(){
			cout<<"X = "<<x<<endl;
			cout<<"Y = "<<y<<endl;
		}
	
};
class Parallelogram: private Shape{
	public:
		void getdata(){
			Shape::getdata();
		}
		void display_area(){
			double area = x*y;
			cout<<"Area of Parallelogam is:"<<area;
		}
		void display_data_members(){
			cout<<"X = "<<x<<endl;
			cout<<"Y = "<<y<<endl;
		}
	
};
int main() {
	int option;
	cout<<"1=>> Area of Triangle."<<endl;
	cout<<"2=>> Area of Rectangle."<<endl;
	cout<<"3=>> Area of parallelogram."<<endl;
	cout<<"\n Please select any of the obove options:";
	cin>>option;
	if(option == 1){
		Triangle t;
		t.getdata();
		t.display_area();
	}
	else if(option == 2){
		Rectangle r;
		r.getdata();
		r.display_area();
	}
	else if(option == 3){
		Parallelogram p;
		p.getdata();
		p.display_area();
	}
	return 0;
}
