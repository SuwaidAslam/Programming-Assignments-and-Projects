#include <iostream>
using namespace std;
double power(double m, int n=2);
int main() {
	int choose,n;
	double m;
	cout<<"Enter 1 to use the default 'n' value and Enter 2 to enter your own value: ";
	cin>>choose;
	if(choose == 1){
		cout<<"Value of M: ";
		cin>>m;
		cout<<power(m);
	}
	else if(choose == 2){
		cout<<"Value of M: ";
		cin>>m;
		cout<<"Value of N: ";
		cin>>n;
		cout<<power(m,n);
	}
}
double power(double m, int n){
	double result=1;
	for(int i=0; i<=n-1; i++){
		result*=m;
	}
	return result;
}
