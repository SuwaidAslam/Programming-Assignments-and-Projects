#include <iostream>
#include <string>
using namespace std;
const int size = 10;
class Sort{
	private:
		int int_array[size];
		char char_array[size];
		double double_array[size];
	public:
		void input(int *p){
			for(int i=0;i<size;i++){
				int_array[i] = *(p);
				p++;
			}
		}
		void input(char *p2){
			for(int i=0;i<size;i++){
				char_array[i] = *(p2);
				p2++;
			}
		}
		void input(double *p3){
			for(int i=0;i<size;i++){
				double_array[i] = *(p3);
				p3++;
			}
		}
        void sorted(){
		   int temp_int;
           char temp_char;
           double temp_double;
        for(int k=0;k<(size-1);k++){
            for(int j=0;j<(size-k-1);j++)
            if(int_array[j]>int_array[j+1])
			{
            temp_int=int_array[j];
            int_array[j]=int_array[j+1];
            int_array[j+1] = temp_int;
			}
        }
        
        for(int k=0;k<(size-1);k++) {
            for(int j=0;j<(size-k-1);j++)
            if(char_array[j]>char_array[j+1])
            {
            temp_char=char_array[j];
            char_array[j]=char_array[j+1];
            char_array[j+1] = temp_char;
            }
        }
        
        for(int k=0;k<(size-1);k++) {
            for(int j=0;j<(size-k-1);j++)
			if(double_array[j]>double_array[j+1])
			{
			temp_double =double_array[j];
			double_array[j]=double_array[j+1];
            double_array[j+1] = temp_double;
			}
            }
       }
        
    
		void display_sorted_arr(){
			cout<<"\n\tSorted int array: \n";
			for(int n=0; n<size; n++){
				cout<<int_array[n]<<" , ";
			}
			cout<<endl;
			cout<<"\tSorted char array: \n";
			for(int n=0; n<size; n++){
				cout<<char_array[n]<<" , ";
			}
			cout<<endl;
			cout<<"\tSorted double array: \n";
			for(int n=0; n<size; n++){
				cout<<double_array[n]<<" , ";
			}
			cout<<endl;
		}
};
int main() {
	int temp_int_array[size];
		cout<<"Enter the values in int array:\n";
	    for(int k=0; k<size; k++){
		cin>>temp_int_array[k];
		}
	int *int_ptr;
	int_ptr = temp_int_array;
	
	char temp_char_array[size];
		cout<<"Enter the values in char array:\n";
	    for(int k=0; k<size; k++){
		cin>>temp_char_array[k];
		}
	char *char_ptr;
	char_ptr = temp_char_array;
	
	double temp_double_array[size];
		cout<<"Enter the values in double array:\n";
	    for(int k=0; k<size; k++){
		cin>>temp_double_array[k];
		}
	double *double_ptr;
	double_ptr = temp_double_array;
	Sort array_obj;
	array_obj.input(int_ptr);
	array_obj.input(char_ptr);
	array_obj.input(double_ptr);
	array_obj.sorted();
	array_obj.display_sorted_arr();
	
	return 0;
}
