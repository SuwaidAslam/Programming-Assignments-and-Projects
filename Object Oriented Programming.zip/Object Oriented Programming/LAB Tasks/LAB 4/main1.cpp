#include <iostream>
#include <string>
#include <cmath>
using namespace std;
class Area{
	private:
		int a, b, c;
	public:
    float area(int a, int b){
	return (0.5*(a*b));
	}
    float area (int a){
	return ((sqrt(3)/4)*(a*a));
	}
    double area (int a, int b, int c){
	float s, pre;
	s= (a+b+c)/2;
	pre = s*(s-a)*(s-b)*(s-c);
	return sqrt(pre);
}	
};

int main() {
	int a, b, c;
	Area obj;
	cout<<"Enter 2 sides to find the area of the right angle triangle: "<<endl;
	cin>>a>>b;
	cout<<"Area="<<obj.area(a, b)<<endl;
	cout<<"Enter 1 sides to find the area of equilateral triangle: "<<endl;
	cin>>a;
	cout<<"Area="<<obj.area(a)<<endl;
	cout<<"Enter 3 sides to find the area of the scalene triangle: "<<endl;
	cin>>a>>b>>c;
	cout<<"Area="<<obj.area(a, b, c)<<endl;
	return 0;
}
