#include <iostream>
#include <string>
using namespace std;
class Swap{
	private:
		int data;
	public:
		Swap() : data(0){
		}
		Swap(const Swap &obj){
			data = obj.data;
		}
		void input (){
			cin>>data;
		}
		int display() const{
			return data;
		}
};
int main() {
	Swap a , b ,c;
	cout<<"\tInput data in 3 objects\n";
	cout<<"Obj A= ";
	a.input();
	cout<<"Obj B= ";
	b.input();
	cout<<"Obj C= ";
	c.input();
	cout<<"\tBefore Swaping\n";
	cout<<"Obj A= "<<a.display()<<endl;
	cout<<"Obj B= "<<b.display()<<endl;
	cout<<"Obj C= "<<c.display()<<endl;
	Swap atemp = a , btemp = b;
	a = c;
	b = atemp;
	c = btemp;
	cout<<"\tAfter Swaping\n";
	cout<<"Obj A= "<<a.display()<<endl;
	cout<<"Obj B= "<<b.display()<<endl;
	cout<<"Obj C= "<<c.display()<<endl;
	return 0;
}
