#include <iostream>
#include <string>
using namespace std;
class Account{
    private:
        string name;
        int acc_num;
        double withdraw_amm;
        double balance;
    public:
        Account() : name("") , acc_num(0) , withdraw_amm(0.0), balance(0.0){
        }
        void input_values(){
            cout<<"\nEnter Your Name:";
            cin>>name;
            cout<<"\nEnter Your Account Number: : ";
            cin>>acc_num;
        }
        void deposit(){
            double dep;
            cout<<"\nEnter The Amount You Want To Deposit: ";
            cin>>dep;
            balance+=dep;
        }
        void withdraw(){
            cout<<"\nYour Current Account Balance Is: "<<balance;
            cout<<"\nEnter The Amount You Want To Withdraw: ";
            cin>>withdraw_amm;
            if(withdraw_amm<=balance){
                balance-=withdraw_amm;
            }
            else{
                cout<<"\nYour Current Account balance Is Low!";
            }
            
        }
        void display(){
            cout<<"\nAccount Name: "<<name;
            cout<<"\nAccount Number: "<<acc_num;
            cout<<"\nAccount Balance: "<<balance;
            cout<<"\nWithdrawal Amount : "<<withdraw_amm;
        }
        
};

int main()
{
    int choice, records;
    cout<<"\nEnter How Many recods: ";
    cin>>records;
    Account obj[records];
    int i = 0,num = 1;
        while(i<=records){
        cout<<"\n\t\tAccount#"<<num;
        cout<<"\n\tPress 1 to input Details: ";
        cout<<"\n\tPress 2 to Deposit Amount: ";
        cout<<"\n\tPress 3 to Withdraw Amount: ";
        cout<<"\n\tPress 4 to Display Account Details: ";
        cout<<"\n\tPress 5 to Exit: ";
        for(int y=0; y<=5; y++){
        cout<<"\nEnter Your Choice: ";
        cin>>choice;
        if(choice == 1){
            obj[i].input_values(); 
        }
        else if(choice == 2){
            obj[i].deposit();
        }
        else if(choice == 3){
            obj[i].withdraw();
        }
        else if(choice == 4){
            obj[i].display();
        }
        else if(choice == 5){
            break;
        }
    }
    i++;
    num++;
    }
    return 0;
}
