#include <iostream>
#include <string>
using namespace std;
class Account{
    private:
        string name;
        int acc_num;
        double withdraw_amm;
        double balance;
    public:
        Account() : name("") , acc_num(0) , withdraw_amm(0.0), balance(0.0){
        }
        void input_values(){
            cout<<"Enter Your Name:";
            cin>>name;
            cout<<"\nEnter Your Account Number: : ";
            cin>>acc_num;
        }
        void deposit(){
            double dep;
            cout<<"Enter The Amount You Want To Deposit: ";
            cin>>dep;
            balance+=dep;
        }
        void withdraw(){
            cout<<"Your Current Account Balance Is: "<<balance;
            cout<<"\nEnter The Amount You Want To Withdraw: ";
            cin>>withdraw_amm;
            if(withdraw_amm<=balance){
                balance-=withdraw_amm;
            }
            else{
                cout<<"\nYour Current Account balance Is Low!";
            }
            
        }
        void display(){
            cout<<"\nAccount Name: "<<name;
            cout<<"\nAccount Number: "<<acc_num;
            cout<<"\nAccount Balance: "<<balance;
            cout<<"\nWithdrawal Amount : "<<withdraw_amm;
        }
        
};

int main()
{
    int choice;
    cout<<"\n\tPress 1 to input Details: ";
    cout<<"\n\tPress 2 to Deposit Amount: ";
    cout<<"\n\tPress 3 to Withdraw Amount: ";
    cout<<"\n\tPress 4 to Display Account Details: ";
    cout<<"\n\tPress 5 to Exit: ";
    Account obj;
    int i = 0;
    while(i<=5){
    cout<<"\nEnter Your Choice: ";
    cin>>choice;
    if(choice == 1){
        obj.input_values();
        continue;
    }
    else if(choice == 2){
        obj.deposit();
        continue;
    }
    else if(choice == 3){
        obj.withdraw();
        continue;
    }
    else if(choice == 4){
        obj.display();
        continue;
    }
    else if(choice == 5){
        exit(0);
    }
    i++;
    }
    return 0;
}
