#include <iostream>
#include <string>
using namespace std;
class Complex{
	private:
		int x , y;
	public:
		Complex() : x(0), y(0){
		}
		Complex(int real , int imag) : x(real) , y(imag){
		}
		friend Complex complex_sum(Complex & , Complex &);
		void show(Complex &comp){
			cout<<"Addition: "<<comp.x << "+" << comp.y <<"i"<<endl;
		}
};
Complex complex_sum(Complex &comp1 , Complex &comp2){
	Complex temp;
	temp.x = comp1.x + comp2.x;
	temp.y= comp1.y+ comp2.y;
	return temp;
}
int main() {
	Complex comp1(10 , 3) , comp2(2 , 2) , temp_comp;
	temp_comp = complex_sum(comp1 , comp2);
	temp_comp.show(temp_comp);
	return 0;
}
