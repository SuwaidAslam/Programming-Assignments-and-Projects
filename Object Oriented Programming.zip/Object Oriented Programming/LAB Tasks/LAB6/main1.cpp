#include <iostream>
#include <string>
using namespace std;
class Class_2;
class Class_1{
	private:
		int val1;
	public:
		void indata(){
			cout<<"Enter Value of X: ";
			cin>>val1;
		}
		void display(){
			cout<<"X = "<<val1<<endl;
		}
		friend void exchange(Class_1 &, Class_2 &);
};
class Class_2{
	private:
		int val2;
	public:
		void indata(){
			cout<<"Enter Value of Y: ";
			cin>>val2;
		}
		void display(){
			cout<<"Y = "<<val2<<endl;
		}
		friend void exchange(Class_1 &, Class_2 &);
};
	void exchange(Class_1 &x, Class_2 &y){
		int temp;
		temp = x.val1;
		x.val1 = y.val2;
		y.val2 = temp;
	}
int main() {
	Class_1 x;
	Class_2 y;
	x.indata();
	y.indata();
	exchange(x,y);
	x.display();
	y.display();
	return 0;
}
