#include <iostream>
using namespace std;
const int MAX = 10;
class Array{
	private:
		int a[MAX];
	public:
		Array(){
	         for(int i = 0; i < MAX; i++) {
	           a[i] = i;
	         }
		}
		int &operator[](int i) {
		try{
			if( i< 0 || i >=MAX)
	        throw i;
	        else
	        return a[i];
		}catch(int num){
			cout<<"Out of range in array references"<<endl;
			return a[0];
		}
      }
};
int main() {
	Array A;
	cout << "Value of A[1] : " << A[1] <<endl;
	cout << "Value of A[8] : " << A[8] <<endl;
	cout << "Value of A[13] : " << A[13]<<endl;
	return 0;
}
