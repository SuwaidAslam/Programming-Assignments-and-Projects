#include <iostream>
#include <cmath>
using namespace std;

class MySqrt{
	private:
		float n;
	public:
		MySqrt() : n(0){}
		MySqrt(float i) : n(i){
		}
		void getNum(){
			cout<<"Enter Number: ";
			cin>>n;
		}
		void sqroot(){
			try{
				if(n<0)
				throw n;
				else
				cout<<"Result: "<<sqrt(n)<<endl;
			}catch(float n){
				cout<<"Number must not be negative for finding square root."<<endl;
			}
		}
};
int main()
{
	MySqrt my_sqrt;
	my_sqrt.getNum();
	my_sqrt.sqroot();
	my_sqrt.getNum();
	my_sqrt.sqroot();
}

