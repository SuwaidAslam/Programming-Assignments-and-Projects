#include <iostream>
#include <string>
using namespace std;
class Value{
	private:
		float x;
	public:
		Value() : x(0) {}
		Value(float &a) : x(a){}
		Value operator + (const Value& rhs) const{
		 Value temp;
         temp.x = x + rhs.x;
		 return temp;
		}
		Value operator - (const Value& rhs) const{
		 Value temp;
         temp.x = x - rhs.x;
		 return temp;
		}
		Value operator * (const Value& rhs){
		 Value temp;
         temp.x = x * rhs.x;
		 return temp;
		}
		Value operator / (const Value& rhs) const{
		 Value temp;
         temp.x = x / rhs.x;
		 return temp;
		}
		Value operator ++ (int){
		 x++;
		 return Value(x);
		}
		Value operator -- (int){
		 x--;
		 return Value(x);
		}
		bool operator < (const Value& rhs) const{
			return (x < rhs.x) ? true : false;
		}
		bool operator > (const Value& rhs) const{
			return (x > rhs.x) ? true : false;
		}
		bool operator >= (const Value& rhs) const{
			return (x >= rhs.x) ? true : false;
		}
		bool operator <= (const Value& rhs) const{
			return (x <= rhs.x) ? true : false;
		}
		friend istream& operator>> (istream &input, Value &rhs){
		input >> rhs.x;
		return input;
		}
		friend ostream& operator<< (ostream& output, const Value &rhs){
		output << rhs.x;
		return output;
		}
};
int main() {
	char operator_sign;
	Value a, b , result;
	cout<<"Enter values and operation: ";
	cin>>a>>operator_sign>>b;
	switch(operator_sign){
		case '+':
		result = a+b;
		cout<<"Ans = "<<result;
			break;
		case '-': 
		result = a-b;
		cout<<"Ans = "<<result;
			break;
		case '*':
		result = a*b;
		cout<<"Ans = "<<result;
			break;
		case '/':
		result = a/b;
		cout<<"Ans = "<<result;
			break;
		default:
			cout<<"Not a Valid operation!"<<endl;
	}
	cout<<"\nIncremented Value of A:"<<a++;
	cout<<"\nIncremented Value of B:"<<b++;
	cout<<"\nDecremented Value of A:"<<a--;
	cout<<"\nDecremented Value of B:"<<b--;
	cout<<"\nA > B: ";
	(a>b) ? cout<<"yes" : cout<<"No";
	cout<<"\nB < A: ";
	(b < a) ? cout<<"yes" : cout<<"No";
	cout<<"\nB > A: ";
	(a > a) ? cout<<"yes" : cout<<"No";
	cout<<"\nA < B: ";
	(a < b) ? cout<<"yes" : cout<<"No";
	cout<<"\nA >= B: ";
	(a <= b) ? cout<<"yes" : cout<<"No";
	cout<<"\nA <= B: ";
	(a <= b) ? cout<<"yes" : cout<<"No";
	return 0;
}
