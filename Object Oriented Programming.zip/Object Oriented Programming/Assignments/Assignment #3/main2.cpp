#include <iostream>
#include <string>
using namespace std;
class Computer{
	protected:
		int wordsize;
		int memory_size;
		int storage_size;
		int speed;
	public:
		Computer(){
			wordsize = 0;
			memory_size = 0;
		    storage_size = 0;
		    speed = 0;
		}
		void get_data(){
			cout<<"Enter Wordsize (in bits):";
			cin>>wordsize;
			cout<<"Enter Memory Size (in MBs):";
			cin>>memory_size;
			cout<<"Enter Storage Size (in MBs):";
			cin>>storage_size;
			cout<<"Enter Speed (in MHz):";
			cin>>speed;
		}
		void put_data(){
			cout<<"Wordsize (in bits):"<<wordsize<<endl;
			cout<<"Memory Size (in MBs):"<<memory_size<<endl;
			cout<<"Storage Size (in MBs):"<<storage_size<<endl;
			cout<<"Speed (in MHz):"<<speed<<endl;
		}
};
class Laptop : private Computer{
	private:
		int length, width, height;
		float weight;
	public:
		Laptop(){
			Computer();
			length = 0;
			width = 0;
			height = 0;
			weight = 0.0;
		}
		void get_data(){
			Computer::get_data();
			cout<<"Enter Length:";
			cin>>length;
			cout<<"Enter Width:";
			cin>>width;
			cout<<"Enter Height:";
			cin>>height;
			cout<<"Enter weight:";
			cin>>weight;
		}
		void put_data(){
			Computer::put_data();
			cout<<"Length:"<<length<<endl;
			cout<<"Width:"<<width<<endl;
			cout<<"Height:"<<height<<endl;
			cout<<"Weight:"<<weight<<endl;
		}
};
int main() {
	Laptop l;
	l.get_data();
	l.put_data();
	return 0;
}
