#include <iostream>
#include <string>
using namespace std;
class Person{
	protected:
		int id;
		string name;
		string address;
	public:
		Person() : id(0), name(""), address(""){
		}
		void get_person_data(){
			cout<<"Enter ID:";
			cin>>id;
			cout<<"Enter Name:";
			cin>>name;
			cout<<"Enter Address:";
			cin>>address;
		}
		void put_person_data(){
			cout<<"ID:"<<id<<endl;
			cout<<"Name:"<<name<<endl;
			cout<<"Address:"<<address<<endl;
		}
};
class Student : public Person{
	private:
		int roll_num;
		float marks;
	public:
		Student() : roll_num(0), marks(0.0){
		}
		void get_student_data(){
			cout<<"Enter Roll Number:";
			cin>>roll_num;
			cout<<"Enter Marks:";
			cin>>marks;
		}
		void put_student_data(){
			cout<<"Roll Number:"<<roll_num<<endl;
			cout<<"Marks:"<<marks<<endl;
		}
};
class Scholarship : public Student{
	private:
		string scholarship_name;
		int amount;
	public:
		Scholarship() : scholarship_name(""), amount(0){
		}
		void get_scholarship_data(){
			cout<<"Enter Scholarship Name:";
			cin>>scholarship_name;
			cout<<"Enter Amount:";
			cin>>amount;
		}
		void put_scholarship_data(){
			cout<<"Scholarship Name:"<<scholarship_name<<endl;
			cout<<"Amount:"<<amount<<endl;
		}
};
int main() {
	Scholarship s;
	s.get_person_data();
	s.get_student_data();
	s.get_scholarship_data();
	s.put_person_data();
	s.put_student_data();
	s.put_scholarship_data();
	return 0;
}
