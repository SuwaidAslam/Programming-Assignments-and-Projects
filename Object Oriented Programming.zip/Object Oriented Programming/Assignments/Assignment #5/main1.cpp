#include <iostream>
#include <string>
using namespace std;
class Employee{
	private:
		string name;
		int age;
		int contact;
		int CNIC;
		string education;
};
class Permanent_EMP: public Employee{
	private:
		int basic_salary;
		int allowances;
	public:
		Permanent_EMP(int slry,int alnc):basic_salary(slry), allowances(alnc){}
		double salary(){
			return (basic_salary + allowances);
		}
};
class Contractual_EMP: public Employee{
	private:
		int basic_salary;
		int commission_percentage;
	public:
		Contractual_EMP(int slry,int cmsn):basic_salary(slry), commission_percentage(cmsn){}
		double salary(){
			return (basic_salary + (basic_salary*commission_percentage/100));
		}
		
};
int main() {
	Permanent_EMP per_emp(50000,2000);
	cout<<"Salary of this Employee: "<<per_emp.salary()<<endl;
	Contractual_EMP cont_emp(60000,1000);
	cout<<"Salary of this Employee: "<<cont_emp.salary()<<endl;
	return 0;
}
