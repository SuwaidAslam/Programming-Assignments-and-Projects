#include <iostream>
#include <string>
using namespace std;
class Turtle;
class Rabbit{
	private:
		int km;
		int meters;
	public:
		Rabbit(int KM, int Meters): km(KM),meters(Meters){}
		friend void ShowTotalDistance(Rabbit,Turtle);
};
class Turtle{
	private:
		int km;
		int meters;
	public:
		Turtle(int KM, int Meters): km(KM),meters(Meters){}
		friend void ShowTotalDistance(Rabbit,Turtle);
};
void ShowTotalDistance(Rabbit rabbit,Turtle turtle){
	int Meters;
	Meters = rabbit.km*1000;
	int total_distance = Meters + rabbit.meters;
	cout<<"Distance Covered by Rabbit in Meters: "<<total_distance<<endl;
	Meters = turtle.km*1000;
	total_distance = Meters + turtle.meters;
	cout<<"Distance Covered by Turtle in Meters: "<<total_distance<<endl;
}
int main() {
	Rabbit rabbit(1,150);
	Turtle turtle(1,150);
	ShowTotalDistance(rabbit,turtle);
	return 0;
}
