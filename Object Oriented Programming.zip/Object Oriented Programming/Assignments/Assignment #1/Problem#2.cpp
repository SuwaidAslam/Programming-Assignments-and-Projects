#include <iostream>
#include <string>
using namespace std;
class Complex{
	private:
		double real_part;
		double imaginary_part;
	public:
		Complex() : real_part(0.0), imaginary_part(0.0){
		}
		Complex(double r,double i){
			real_part = r;
			imaginary_part = i;
		}
		void addition(Complex a, Complex b){
			   real_part = a.real_part + b.real_part;
               imaginary_part = a.imaginary_part + b.imaginary_part;
                cout<<"\nResult = " << real_part << " + " << imaginary_part << "i";
                print();
		}
		void subtraction(Complex a, Complex b){
			real_part = a.real_part - b.real_part;
            imaginary_part = a.imaginary_part - b.imaginary_part;
            cout<<"\nResult = " << real_part << " - " << imaginary_part << "i";
            print();
		}
		void print(){
			cout<<"\nResult = " <<"("<<real_part<<","<< imaginary_part <<")";
		}
};
int main() {
	double r1 , i1, r2, i2;
	cout<<"Input 1st Complex Number\n";
	cout<<"Enter Real Number: ";
	cin>>r1;
	cout<<"Enter Imaginary Number: ";
	cin>>i1;
	cout<<"\nInput 2nd Complex Number\n";
	cout<<"Enter Real Number: ";
	cin>>r2;
	cout<<"Enter Imaginary Number: ";
	cin>>i2;
	Complex a(r1,i1),b(r2,i2),c;
	cout<<"\nAddition Result";
	c.addition(a , b);
	cout<<"\n\nSubtraction Result";
	c.subtraction(a,b);
	return 0;
}
