#include <iostream>
#include <string>
using namespace std;
class ToolBoth{
	private:
		unsigned int total_cars;
		unsigned int paid_cars;
		unsigned int unpaid_cars;
		double money_collected;
	public:
		ToolBoth() : total_cars(0), paid_cars(0), unpaid_cars(0), money_collected(0){
		}
		void payingCar(unsigned int paid){
			for(int i=1; i<=paid ; i++)
			{
			total_cars+=1;
			money_collected+=50;
			paid_cars+=1;
			}
		}
		void noPayCar(unsigned int unpaid){
			for(int i=1; i<=unpaid ; i++)
			{
			total_cars+=1;
			unpaid_cars+=1;
			}
		}
		void display(){
			cout<<"\nTotal Cars: "<<total_cars<<endl;
			cout<<"Paid Cars: "<<paid_cars<<endl;
			cout<<"Unpaid Cars: "<<unpaid_cars<<endl;
			cout<<"Total Amount: "<<money_collected<<endl;
		}
};
int main() {
	unsigned int paid_c;
	unsigned int unpaid_c;
	cout<<"Enter the number of Paid Cars Passed: ";
	cin>>paid_c;
	cout<<"\nEnter the number of Unpaid Cars Passed: ";
	cin>>unpaid_c;
	ToolBoth obj;
	obj.payingCar(paid_c);
	obj.noPayCar(unpaid_c);
	obj.display();
	return 0;
}
