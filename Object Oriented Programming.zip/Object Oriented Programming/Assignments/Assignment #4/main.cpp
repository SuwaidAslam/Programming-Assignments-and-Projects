#include <iostream>
#include <vector>
#include <cmath>
#include <string>
using namespace std;
const int size = 6;
class Shape{
	public:
		string name;
		Shape(){
			name = "generic:";
		}
		virtual ~Shape(){
		}
		virtual void print_name() const = 0;
};
// 2D Shape
class TwoDimensionalShape : public Shape{
	public:
		virtual double getArea() = 0;
};
class Circle : public TwoDimensionalShape{
	private:
		double radius;
	public:
		Circle(double r) : radius(r) {
			name = "Circle:";
		}
	double getArea(){
		double area = 3.14 * radius * radius;
		return area;
	}
	void print_name() const{
		cout<<name<<endl;
	}
};
class Square : public TwoDimensionalShape{
	private:
		double x,y;
	public:
		Square(double a, double b): x(a), y(b){
			name = "Square:";
		}
		double getArea(){
			double area = x * y;
			return area;
		}
		void print_name() const{
			cout<<name<<endl;
		}
};
class Triangle : public TwoDimensionalShape{
	private:
		double base, height;
	public:
		Triangle(double b, double h): base(b), height(h){
			name = "Triangle:";
		}
		double getArea(){
			double area = (0.5)*base*height;
			return area;
		}
		void print_name() const{
			cout<<name<<endl;
		}
};
//3D Shape
class ThreeDimensionalShape : public Shape{
	public:
	virtual double getVolume() = 0;
	virtual double getArea() = 0;
};
class Sphere : public ThreeDimensionalShape{
	private:
		double radius;
	public:
		Sphere(double r) : radius(r){
			name = "Sphere:";
		}
		double getVolume(){
			double volume = (4/3) * 3.14 * radius * radius * radius;
			return volume;
		}
		double getArea(){
			double area = 4 * 3.14 * radius * radius;
			return area;
		}
		void print_name() const{
			cout<<name<<endl;
		}
};
class Cube : public ThreeDimensionalShape{
	private:
			double sides;
	public:
		Cube(double s): sides(s){
			name = "Cube:";
		}
		double getVolume(){
			double volume = sides * sides * sides;
			return volume;
		}
		double getArea(){
			double area = 6* sides* sides;
			return area;
		}
		void print_name() const{
			cout<<name<<endl;
		}
};
class Tetrahedron : public ThreeDimensionalShape{
	private:
		double sides;
	public:
		Tetrahedron(double s): sides(s){
			name = "Tetrahedron:";
		}
		double getVolume(){
			double volume = ((sides * sides * sides)* sqrt(2))/12;
			return volume;
		}
		double getArea(){
			double area = sides* sides * sqrt(3);
			return area;
		}
		void print_name() const{
			cout<<name<<endl;
		}
};

int main(){
	vector<Shape *>shapes(size);
	shapes[0] = new Circle(8.5);
	shapes[1] = new Square(5, 9);
	shapes[2] = new Triangle(9.2, 4);
	shapes[3] = new Sphere(16);
	shapes[4] = new Cube(12);
	shapes[5] = new Tetrahedron(21.5);
	
	for(int i=0;i<size;i++){
		cout<<endl;
		shapes[i]->print_name();
		
 		TwoDimensionalShape *twoDimensionalSpace = dynamic_cast<TwoDimensionalShape *>(shapes[i]);
		if(twoDimensionalSpace !=0){
			cout<<"Area: "<<twoDimensionalSpace->getArea()<<endl;
		}
		ThreeDimensionalShape *threeDimensionalSpace = dynamic_cast<ThreeDimensionalShape *>(shapes[i]);
		if(threeDimensionalSpace !=0){
			cout<<"Area: "<<threeDimensionalSpace->getArea()<<endl;
			cout<<"Volume: "<<threeDimensionalSpace->getVolume()<<endl;
		}	
	}
	return 0;
}
