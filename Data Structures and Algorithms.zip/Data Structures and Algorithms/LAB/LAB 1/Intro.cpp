#include <iostream>
using namespace std;
int main()
{
int x=10;
int *ptr=&x;
int **ptr2=&ptr;
// Access 10
cout<<x;
cout<<"\n";
cout<<*ptr;
cout<<"\n";
cout<<**ptr2;
cout<<"\n";
// Access Address of x
cout<<"\n";
cout<<&x;
cout<<"\n";
cout<<ptr;
cout<<"\n";
cout<<*ptr2;
// Access Address of PTR
cout<<"\n";
cout<<&ptr;
cout<<"\n";
cout<<ptr2;
//Access Address of PTR2
cout<<"\n";
cout<<&ptr2;
}
