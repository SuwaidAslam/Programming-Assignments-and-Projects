#include <iostream>
using namespace std;
struct node
{
	int priority;
	int info;
	node *next;
};
class Priority_Queue
{
    private:
        node *front;
    public:
        Priority_Queue()
        {
            front = NULL;
        }
        void Enqueue(int, int);
        void Dequeue();
        void display();
        void MoveNthFront(int);
};
void Priority_Queue::Enqueue(int item, int priority)
{
    node *tmp, *q;
    tmp = new node;
    tmp->info = item;
    tmp->priority = priority;
    if (front == NULL || priority > front->priority)
    {
        tmp->next = front;
        front = tmp;
    }
    else
    {
        q = front;
        while (q->next != NULL && q->next->priority >= priority)
            q=q->next;
        tmp->next = q->next;
        q->next = tmp;
    }
}
void Priority_Queue::Dequeue()
{
    node *tmp;
    if(front == NULL)
        cout<<"Queue Underflow\n";
    else
    {
        tmp = front;
        cout<<"Deleted item is: "<<tmp->info<<endl;
        front = front->next;
        delete tmp;
    }
}
void Priority_Queue::display()
{	
    node *ptr;
    ptr = front;
    if (front == NULL)
        cout<<"Queue is empty\n";
    else
    {	cout<<"Queue is :\n";
        cout<<"Priority       Item\n";
        while(ptr != NULL)
        {
            cout<<ptr->priority<<"     "<<ptr->info<<endl;
            ptr = ptr->next;
        }
    }
}
void Priority_Queue::MoveNthFront(int n){
	int count = 0;
	node *temp = front;
	while(temp!=NULL){
		count++;
		if(count == n){
			break;
		}
		temp = temp->next;
	}
	int t = front->info;
	front->info = temp->info;
	temp->info = t;
}
int main()
{
    int choice, item, priority;
    Priority_Queue pq; 
    do
    {
        cout<<"1.Insert\n";
        cout<<"2.Delete\n";
        cout<<"3.Display\n";
        cout<<"4.Move Nth element to Front\n";
        cout<<"5.Quit\n";
        cout<<"Enter your choice : "; 
        cin>>choice;
        switch(choice)
        {
        case 1:
            cout<<"Input Value: ";
            cin>>item;
            cout<<"Enter its priority : ";
            cin>>priority;
            pq.Enqueue(item, priority);
            break;
        case 2:
            pq.Dequeue();
            break;
        case 3:
            pq.display();
            break;
        case 4:
        	cout<<"Enter the Nth element to be moved: ";
        	int n;
        	cin>>n;
        	pq.MoveNthFront(n);
        	break;
        case 5:
            break;
        default :
            cout<<"Wrong choice\n";
        }
    }
    while(choice != 5);
    return 0;
}
