#include <iostream>
using namespace std;
struct node
{
	int priority;
	int info;
	node *next;
};
class Priority_Queue
{
    private:
        node *front;
    public:
        Priority_Queue()
        {
            front = NULL;
        }
        void Enqueue(int,int);
        void Dequeue();
        void display();
        void Delete_Max();
        void Delete_Min();
};
void Priority_Queue::Enqueue(int item, int priority)
{
    node *tmp, *q;
    tmp = new node;
    tmp->info = item;
    tmp->priority = priority;
    if (front == NULL || priority > front->priority)
    {
        tmp->next = front;
        front = tmp;
    }
    else
    {
        q = front;
        while (q->next != NULL && q->next->priority >= priority)
            q=q->next;
        tmp->next = q->next;
        q->next = tmp;
    }
}
void Priority_Queue::Dequeue()
{
    node *tmp;
    if(front == NULL)
        cout<<"Queue Underflow\n";
    else
    {
        tmp = front;
        cout<<"Deleted item is: "<<tmp->info<<endl;
        front = front->next;
        delete tmp;
    }
}
void Priority_Queue::display()
{
    node *ptr;
    ptr = front;
    if (front == NULL)
        cout<<"Queue is empty\n";
    else
    {	cout<<"Queue is :\n";
        cout<<"Priority       Item\n";
        while(ptr != NULL)
        {
            cout<<ptr->priority<<"     "<<ptr->info<<endl;
            ptr = ptr->next;
        }
    }
}
void Priority_Queue::Delete_Max(){
	node *tmp;
    if(front == NULL)
        cout<<"Queue Underflow\n";
    else
    {
        tmp = front;
        front = front->next;
        delete tmp;
    }
}
void Priority_Queue::Delete_Min(){
	node *temp = front;
	while(temp->next->next!=NULL){
		temp = temp->next;
	}
	delete temp->next;
	temp->next = NULL;
}
int main()
{
    int choice, item, priority;
    Priority_Queue pq; 
    do
    {
        cout<<"1.Insert\n";
        cout<<"2.Delete\n";
        cout<<"3.Display\n";
        cout<<"4.Delete Max Priority Element\n";
        cout<<"5.Delete Min Priorit Element\n";
        cout<<"6.Quit\n";
        cout<<"Enter your choice : "; 
        cin>>choice;
        switch(choice)
        {
        case 1:
            cout<<"Input Value: ";
            cin>>item;
            cout<<"Enter its priority : ";
            cin>>priority;
            pq.Enqueue(item, priority);
            break;
        case 2:
            pq.Dequeue();
            break;
        case 3:
            pq.display();
            break;
        case 4:
        	pq.Delete_Max();
        	break;
        case 5:
        	pq.Delete_Min();
        	break;
        case 6:
            break;
        default :
            cout<<"Wrong choice\n";
        }
    }
    while(choice != 6);
    return 0;
}
