#include<iostream>
using namespace std;
struct node
{
    int data;
    node *next;
};
class Queue{
	private:
		node *front;
		node *rear;
	public:
		Queue(){
			front = NULL;
			rear = NULL;
		}
		void Enqueue(int);
		void Add(int,int);
		void Subtract(int,int);
		void Multiply(int,int);
		void Divide(int,int);
		void Dequeue();
};
void Queue::Enqueue(int x)
{
    node *temp = new node;
    temp->data = x;
    temp->next = NULL;
    if(front == NULL)
    {
        front = rear = temp;
        rear->next = NULL;
    }
    else
    {
        rear->next = temp;
        rear = temp;
        rear->next = NULL;
    }
}
void Queue::Dequeue()
{
    if(front == NULL)
    {
        cout<<"empty queue\n";
    }
    else
    {
        node *temp = front;
        front = front->next;
        delete temp;
    }
}
void Queue::Add(int x,int y){
	this->Enqueue(x);
	this->Enqueue(y);
	int result = front->data + rear->data;
	this->Enqueue(result);
	cout<<"Output: "<<rear->data<<endl;
	this->Dequeue();
	this->Dequeue();
	this->Dequeue();
}
void Queue::Subtract(int x,int y){
	this->Enqueue(x);
	this->Enqueue(y);
	int result = front->data - rear->data;
	this->Enqueue(result);
	cout<<"Output: "<<rear->data<<endl;
	this->Dequeue();
	this->Dequeue();
	this->Dequeue();
}
void Queue::Multiply(int x,int y){
	this->Enqueue(x);
	this->Enqueue(y);
	int result = front->data * rear->data;
	this->Enqueue(result);
	cout<<"Output: "<<rear->data<<endl;
	this->Dequeue();
	this->Dequeue();
	this->Dequeue();
}
void Queue::Divide(int x,int y){
	this->Enqueue(x);
	this->Enqueue(y);
	int result = front->data / rear->data;
	this->Enqueue(result);
	cout<<"Output: "<<rear->data<<endl;
	this->Dequeue();
	this->Dequeue();
	this->Dequeue();
}
int main()
{
	Queue queue;
	int ch, val;
	int x , y;
   cout<<"1) Add"<<endl;
   cout<<"2) Subtract"<<endl;
   cout<<"3) Multiply"<<endl;
   cout<<"4) Divide"<<endl;
   cout<<"5) Exit"<<endl;
   do {
      cout<<"Enter choice: "<<endl;
      cin>>ch;
      switch(ch) {
         case 1:
		 	cout<<"Enter X: "; cin>>x;
		 	cout<<"Enter Y: "; cin>>y;
		 	queue.Add(x,y);
            break;
         case 2:
         	cout<<"Enter X: "; cin>>x;
		 	cout<<"Enter Y: "; cin>>y;
		 	queue.Subtract(x,y);
            break;
         case 3:
         	cout<<"Enter X: "; cin>>x;
		 	cout<<"Enter Y: "; cin>>y;
		 	queue.Multiply(x,y);
            break;
         case 4:
            cout<<"Enter X: "; cin>>x;
		 	cout<<"Enter Y: "; cin>>y;
		 	queue.Divide(x,y);
            break;
         case 5:
         	cout<<"Exit"<<endl;
			break;
         default:
            cout<<"Invalid Choice"<<endl;
      }
   }while(ch!=5);
}
