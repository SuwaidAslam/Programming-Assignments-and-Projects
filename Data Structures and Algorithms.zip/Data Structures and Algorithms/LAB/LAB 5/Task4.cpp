#include <iostream>
using namespace std; 
struct Node {
    int data; 
    struct Node* next; 
}; 
 
class Stack{
	private:
		Node *top;
	public:
		Stack(){
			top = NULL;
		}
		void push(int);
		void pop();
		void display();
		bool operator == (const Stack &other) const{
			Node *temp = this->top;
			Node *temp1 = other.top;
			try{
				while(temp1!=NULL && temp!=NULL){
				if(temp->data != temp1->data){
					return false;
				}
				temp = temp->next;
				temp1 = temp1->next;
			}
			}
			catch(...){
				return false;
			}
			return true;
		}
};
void Stack::push(int data) 
{
    Node* temp = new Node; 
    if (!temp) { 
        cout << "\nStack Overflow"; 
    }
    temp->data = data; 
    temp->next = top;
    top = temp; 
}
  
void Stack::pop() 
{
     Node* temp; 
    if (top == NULL) {
        cout << "\nStack Underflow" << endl; 
    } 
    else {
        temp = top; 
        top = top->next; 
        temp->next = NULL; 
        delete temp;
    } 
}
void Stack::display()  
{
    Node* temp; 
    if (top == NULL) { 
        cout << "\nStack Underflow";  
    } 
    else { 
        temp = top; 
        while (temp != NULL) { 
            cout <<  temp->data << " ";
            temp = temp->next; 
        } 
    } 
}
int main() 
{
Stack stack1, stack2;
stack1.push(10);
stack1.push(20);
stack1.push(30);
stack2.push(10);
stack2.push(20);
stack2.push(30);
if(stack1 == stack2){
	cout<<"Same"<<endl;
}
else
cout<<"Not Same"<<endl;
    return 0; 
}
