#include<iostream>
using namespace std;
struct node
{
    int data;
    node *next;
};
class Queue{
	private:
		node *front;
		node *rear;
	public:
		Queue(){
			front = NULL;
			rear = NULL;
		}
		void Enqueue(int);
		void Dequeue();
		void Display();
};
void Queue::Enqueue(int x)
{
    node *temp = new node;
    temp->data = x;
    temp->next = NULL;
    if(front == NULL)
    {
        front = rear = temp;
        rear->next = NULL;
    }
    else
    {
        rear->next = temp;
        rear = temp;
        rear->next = NULL;
    }
}
void Queue::Dequeue()
{
    if(front == NULL)
    {
        cout<<"empty queue\n";
    }
    else
    {
        node *temp = front;
        front = front->next;
        delete temp;
    }
}
void Queue::Display(){
	node *temp = front;
	while(temp!=NULL){
		cout<<temp->data<<" ";
		temp = temp->next;
	}
	cout<<endl;
}
int main()
{
	Queue queue;
	queue.Enqueue(5);
	queue.Enqueue(10);
	queue.Enqueue(15);
	queue.Enqueue(20);
	queue.Dequeue();
	queue.Enqueue(2);
	queue.Enqueue(4);
	queue.Enqueue(6);
	queue.Dequeue();
	queue.Display();
}
