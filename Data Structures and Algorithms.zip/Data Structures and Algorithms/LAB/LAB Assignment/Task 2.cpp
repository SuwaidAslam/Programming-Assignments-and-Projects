#include <iostream>
#include <cmath>
using namespace std; 

struct Node { 
    int data; 
    struct Node* next; 
}; 
 
class Stack{
	private:
		Node *top;
	public:
		Stack(){
			top = NULL;
		}
		void push(int);
		void pop();
		void display();
};
void Stack::push(int data) 
{
    Node* temp = new Node; 
    temp->data = data;
    temp->next = NULL;
    if (!temp) {
        cout << "\nStack Overflow"; 
    }
    if(top == NULL){
    	top = temp;
	}
	else{
		temp->next = top; 
		top = temp;
	}
}
void Stack::pop() 
{
     Node* temp; 
    if (top == NULL) {
        cout << "\nStack Underflow" << endl; 
    } 
    else {
        temp = top; 
        top = top->next; 
        temp->next = NULL; 
        delete temp;
    } 
}
void Stack::display()  
{
    Node* temp; 
    if (top == NULL) { 
        cout << "\nStack Underflow";  
    } 
    else {
        temp = top;
        cout<<"Prime Factors are: "<<endl;
        while (temp != NULL) {
            cout <<  temp->data <<endl;
            temp = temp->next; 
        } 
    } 
}
Stack stack;
void primeFactors(int n) 
{
    // Print the number of 2s that divide n
    while (n % 2 == 0) 
    {
        stack.push(2);
        n = n/2; 
    }
  
    // n must be odd at this point. So we can skip 
    // one element (Note i = i +2) 
    for (int i = 3; i <= sqrt(n); i = i + 2) 
    {
        // While i divides n, print i and divide n 
        while (n % i == 0)
        { 
            stack.push(i);
            n = n/i; 
        } 
    }
  
    // This condition is to handle the case when n 
    // is a prime number greater than 2 
    if (n > 2)
    	stack.push(n);
}
int main()
{
	cout<<"Enter a Posiive number: ";
	int i;
	cin>>i;
	primeFactors(i);
	stack.display();
    return 0; 
} 
