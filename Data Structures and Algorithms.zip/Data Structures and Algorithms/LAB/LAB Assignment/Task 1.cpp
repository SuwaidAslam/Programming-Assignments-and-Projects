#include <iostream>
#include <string>
using namespace std; 
int prec(char);
bool isOperand(char);
struct Node {
    char data;
    Node* next; 
}; 
class Stack{
	private:
		Node *top;
	public:
		Stack(){
			top = NULL;
		}
		void push(char);
		char pop();
		void display();
		char peek();
		bool isEmpty();
		string ReturnAll();
		string PopTillLowPrec(char);
		string PopTillBracket();
};
void Stack::push(char data) 
{
    Node* temp = new Node; 
    temp->data = data;
    temp->next = NULL;
    if (!temp) {
        cout << "\nStack Overflow"; 
    }
    if(top == NULL){
    	top = temp;
	}
	else{
		temp->next = top; 
		top = temp;
	}
}
char Stack::pop() 
{
     Node* temp; 
    if (top == NULL) {
        cout << "\nStack Underflow" << endl; 
    } 
    else {
        temp = top;
        top = top->next; 
        temp->next = NULL; 
        return temp->data;
    }
}
void Stack::display()  
{
    Node* temp; 
    if (top == NULL) { 
        cout << "\nStack Underflow";  
    } 
    else { 
        temp = top; 
        while (temp != NULL) { 
            cout <<  temp->data << " ";
            temp = temp->next; 
        }
    }
}
char Stack::peek(){
	return top->data;
}
bool Stack::isEmpty(){
	if(top == NULL)
		return true;
	else
		return false;
}
string Stack::ReturnAll(){
	string ALL;
	Node *temp = top;
	while(temp!=NULL){
		ALL+= temp->data;
		temp = temp->next;
	}
	return ALL;
}
string Stack::PopTillLowPrec(char c){
	string AllPoped;
	Node *tmp = top;
	while(tmp!=NULL){
		if(prec(tmp->data) < prec(c) && tmp->data != '(')
			break;
		AllPoped+= this->pop();
		tmp = tmp->next;
	}
	return AllPoped;
}
string Stack::PopTillBracket(){
	string AllPoped;
	Node *temp = top;
	while(temp!=NULL){
		if(temp->data == '(')
			break;
		AllPoped+= this->pop();
		temp = temp->next;
	}
	return AllPoped;
}
int prec(char c){
	if(c == '+' || c == '-')
		return 1;
	if(c == '*' || c == '/')
		return 2;	
	if(c == '^')
		return 3;
	return -1;
}
bool isOperand(char x){
	if((x >= 'a' && x <='z') || (x >= 'A' && x <= 'Z'))
		return true;
	return false;
}
string infixToPostfix(string exp){
	Stack stack;
	string postfix;
	for(int i = 0; i<= exp.length(); i++){
		if(isOperand(exp[i]))
			postfix+= exp[i];
		else{
			if(stack.isEmpty() || exp[i] == '(' || stack.peek() == '(')
				stack.push(exp[i]);
			else if(exp[i] == ')'){
				postfix+= stack.PopTillBracket();
				stack.pop();
			}
			else if(prec(exp[i]) > prec(stack.peek()))
				stack.push(exp[i]);
			else if(prec(exp[i]) <= prec(stack.peek())){
				postfix+= stack.PopTillLowPrec(exp[i]);
				if(stack.isEmpty())
					stack.push(exp[i]);
				else if(prec(exp[i]) == prec(stack.peek())){
					postfix+= stack.pop();
					stack.push(exp[i]);
				}
			}
		}
	}
	postfix+=stack.ReturnAll();
	return postfix;
}
int main()
{
	string expression = "(A+B)*(C+D)-E";
	cout<<"Postfix Expression: "<<infixToPostfix(expression);
    return 0;
}
