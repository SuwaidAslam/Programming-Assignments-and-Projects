#include<iostream>
#include<stdio.h>
#include<conio.h>
using namespace std;
class Stack;
struct Node
{
    int data;
    Node *next;
};
class Queue{
	private:
		Node *front;
		Node *rear;
	public:
		Queue(){
			front = NULL;
			rear = NULL;
		}
		void Enqueue(int);
		int Dequeue();
		void Display();
};
void Queue::Enqueue(int x)
{
    Node *temp = new Node;
    temp->data = x;
    temp->next = NULL;
    if(front == NULL)
    {
        front = rear = temp;
        rear->next = NULL;
    }
	else
    {
        rear->next = temp;
        rear = temp;
        rear->next = NULL;
    }
}
int Queue::Dequeue()
{
    if(front == NULL)
    {
        cout<<"empty queue\n";
    }
    else
    {
        Node *temp = front;
        front = front->next;
        int d = temp->data;
        delete temp;
        return d;
    }
}
void Queue::Display(){
	Node *temp = front;
	while(temp!=NULL){
		cout<<temp->data<<" ";
		temp = temp->next;
	}
	cout<<endl;
}
class Stack{
	private:
		Node *top;
	public:
		Stack(){
			top = NULL;
		}
		void push(int);
		int pop();
		void display();
		Node *ReturnTop(){
			return top;
		}
};
void Stack::push(int data) 
{
    Node* temp = new Node; 
    temp->data = data;
    temp->next = NULL;
    if (!temp) {
        cout << "\nStack Overflow"; 
    }
	temp->data = data; 
	temp->next = top;
	top = temp;
} 
int Stack::pop() 
{
    Node* temp;
    if (top == NULL) {
        cout << "\nStack Underflow" << endl; 
    } 
    else {
        temp = top;
        top = top->next; 
        temp->next = NULL;  
        int t = temp->data;
        delete temp;
        return t;
    }
}
void Stack::display()  
{
    Node* temp; 
    if (top == NULL) { 
        cout << "\nStack Underflow";  
    } 
    else {
        temp = top;
        while (temp != NULL) {
            cout <<  temp->data << " ";
            temp = temp->next; 
        }
    }
}
Stack stack;
void reverseStack (Stack &stk){
	Queue *queue = new Queue;
	Node *tmp1 = stk.ReturnTop();
	int count = 1;
	while(tmp1 != NULL){
		count++;
		tmp1 = tmp1->next;
	}
	for(int i = 1; i<count;i++){
		queue->Enqueue(stk.pop());
	}
	for(int i = 1; i<count;i++){
		stk.push(queue->Dequeue());
	}
}
int main()
{
int ch, val;
   cout<<"1) Push in stack"<<endl;
   cout<<"2) Pop from stack"<<endl;
   cout<<"3) Display stack"<<endl;
   cout<<"4) Reverse Stack"<<endl;
   cout<<"5) Exit"<<endl;
   do {
      cout<<"Enter choice: "<<endl;
      cin>>ch;
      switch(ch) {
         case 1: {   
            cout<<"Enter value to be pushed:"<<endl;
            cin>>val;
            stack.push(val);
            break;
         }
         case 2: {
            stack.pop();
            break;
         }
         case 3: {
            stack.display();
            break;
         }
         case 4: {
         	reverseStack(stack);
			break;
		 }
         case 5: {
            cout<<"Exit"<<endl;
            break;
         }
         default: {
            cout<<"Invalid Choice"<<endl;
         }
      }
   }while(ch!=5);
}
