#include <iostream>
using namespace std;

struct Node
{
    int data;
    Node *next;
    Node(){
	}
    Node(int d): data(d){
	}
};

class LinkedList
{
private:
    Node *head,*tail;
public:
    LinkedList()
    {
        head = NULL;
        tail = NULL;
    }

    void add_node(int n)
    {
        Node *tmp = new Node;
        tmp->data = n;
        tmp->next = NULL;

        if(head == NULL)
        {
            head = tmp;
            tail = tmp;
        }
        else
        {
            tail->next = tmp;
            tail = tail->next;
        }
    }
    
    void display()
    {
        Node *tmp;
        tmp = head;
        while (tmp != NULL)
        {
            cout << tmp->data << endl;
            tmp = tmp->next;
        }
    }
    
    Node* gethead()
    {
        return head;
    }
    void del_first_node(){
    	Node *temp;
    	temp = head;
    	head = head->next;
    	delete temp;
	}
	void del_last_node(){
		Node *temp, *temp2;
		temp = tail;
		temp2 = head;
		if(temp2->next==NULL){
			head = NULL;
			tail = NULL;
			delete temp2;
		}
		else{
			while(temp2->next->next!=NULL)
				temp2 = temp2->next;
			
			tail = temp2;	
			temp2->next = NULL;
			delete temp;	
		}
	}
	void swap(){
		Node *temp = NULL, *second_last = head;
		while(second_last->next->next!=NULL){
			second_last = second_last->next;
		}
		temp = head;
		head = tail;
		head->next = temp->next;
		tail = temp;
		tail->next = NULL;
		second_last->next = tail;
	}
	void reverse(){
		Node* current = head;
        Node *prev = NULL, *next = NULL;
 
        while (current != NULL) {
            next = current->next;
            current->next = prev;
            prev = current;
            current = next;
        }
        head = prev;
	}
	bool search(int i){
		Node *current = head;
		while (current != NULL) {
			if(i == current->data){
				return true;
			}
            current = current->next;
        }
        return false;
	}
	void remove4(){
		int counter = 1;
		Node *current = head;
		Node *prev = NULL;
		while(current!=NULL){
			if(counter==4){
				prev->next = current->next;
				delete current;
				break;
			}
			counter++;
			prev = current;
			current = current->next;
		}
	}
	void insertSecond(Node *temp){
		Node *First = head;
		Node *Next = head->next;
		head->next = temp;
		temp->next = Next;
	}
};

int main()
{
	LinkedList list;
	list.add_node(50);
	list.add_node(100);
	list.add_node(200);
	list.add_node(500);
	list.add_node(1000);
	list.add_node(2000);
	list.add_node(3000);
	Node *temp = new Node(555);
	list.insertSecond(temp);
	//list.reverse();
	//list.swap();
	//list.del_first_node();
	//list.del_last_node();
	//list.remove4();
	list.display();
}
