#include <iostream>
#include <conio.h>
using namespace std;

struct node {
	int data;
	node* left;
	node* right;
};

class BST
{
	private:
		node *root;
		node *current;
	public:
		BST()
		{
			root = NULL; 	
			current = NULL;
		}
		void Insert(int);
		void Display(node*, int);
		void Search(int);
		node *returnRoot();
};
node* BST::returnRoot(){
	return root;
}
void BST::Insert(int d){
	node *temp = new node;
	temp->data = d;
	temp->left = NULL;
	temp->right = NULL;
	if(root == NULL){
		root = temp;
	}
	else{
		current = root;
		while(current != NULL){
		if(d < current->data){
			if(current->left == NULL){
				current->left = temp;
				return ;
			}
			else{
				current = current->left;
			}
		}
		else if(d >current->data){
			if(current->right == NULL){
				current->right = temp;
				return ;
			}
			else{
				current = current->right;
			}
		}
		else if(d == current->data){
			return;
		}
	}
}
}
void BST::Display(node *r, int space){
	//reverse_Inorder Display
   if (r == NULL) {
        return;
    }
    space+=5;
    Display(r->right, space);
    cout<<endl;
    for(int i=5;i<space;i++)
    	cout<<" ";
    cout << r->data << endl;
    Display(r->left, space);
}

void BST::Search(int v){
	if(root == NULL){
		return ;
	}
	else{
		current = root;
		while(current != NULL){
			if(v == current->data){
				cout<<v<<" element is present!"<<endl;
				return ;
			}
			else if(v < current->data){
				if(current->left == NULL){
					break;
				}
				else{
					if(current->left->data == v){
						cout<<v<<" element is present!"<<endl;
						return;
					}
					else
						current = current->left;
				}
			}
			else if(v > current->data){
				if(current->right == NULL){
					break;
				}
				else{
					if(current->right->data == v){
						cout<<v<<" element is present!"<<endl;
						return ;
					}
					else
						current = current->right;
				}
			}
	}
	cout<<"Element Not Found!"<<endl;
	
}
}

int main()
{
	BST bst;
	bool Runing = true;
	int option = 0;
	while(Runing)
	{
		system("CLS");
		cout << "\t\t\t\t-----Binary Search Tree------\n";
		cout << "\t\t\t\t1-Input\n";
		cout << "\t\t\t\t2-Display\n";
		cout << "\t\t\t\t3-Search\n";
		cout << "\t\t\t\t4-Exit\n";
		cout << "Enter Option: ";
		cin >> option;
		switch(option) {
		case 1:
			int option;
			do{
				int v;
				cout<<"Enter Value: ";
				cin>>v;
				bst.Insert(v);
				cout<<"Add one more Node?(1/0): ";
				cin>>option;
			}while(option==1);
			getch();
			break;
		case 2:
			bst.Display(bst.returnRoot(), 5);
			getch();
			break;
		case 3:
			cout<<"Enter Value to Search: ";
			int value;
			cin>>value;
			bst.Search(value);
			getch();
			break;
		case 4:
			Runing = false;
			cout << "Press Any key to Continue...!";
			getch();
			break;
		default:
			cout << "Invalid Choice!";
			getch();
		}
	}
	return 0;
}
