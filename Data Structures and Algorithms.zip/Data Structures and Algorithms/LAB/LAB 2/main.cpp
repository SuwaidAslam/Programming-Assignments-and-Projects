#include <iostream>
using namespace std;
// 1 - input matirx size; cin vlaues from user, measure digonal vlaue, sum and compare and avalutae witch one is greater
// 2 - array with pointer traverse it
int main() {
	int size;
	int left_diag = 0;
	int right_diag = 0;
	cout<<"Enter size of Matrix: ";
	cin>>size;
	int matrix[size][size];
	for(int i=0;i<size;i++){
		for(int j=0;j<size;j++){
			cout<<"Enter value: ";
			cin>>matrix[i][j];
		}
	}
	//i = row and j = colomn
	for(int i=0;i<size;i++){
		for(int j=0;j<size;j++){
			if(i==j){
				left_diag += matrix[i][j];
			}
			if((i+j) == size-1){
				right_diag += matrix[i][j];
			}
	}
	}
	if(left_diag>right_diag){
		cout<<"Left diagonal is greater\n";
		cout<<"Value of Left Diagonal is: "<<left_diag<<endl;
		cout<<"Value of Right Diagonal is: "<<right_diag<<endl;
	}
	else if(right_diag>left_diag){
		cout<<"Right diagonal is greater\n";
		cout<<"Value of Left Diagonal is: "<<left_diag<<endl;
		cout<<"Value of Right Diagonal is: "<<right_diag<<endl;
	}
	else{
		cout<<"Right and Left diagonals are same\n";
		cout<<"Value of Left Diagonal is: "<<left_diag<<endl;
		cout<<"Value of Right Diagonal is: "<<right_diag<<endl;
	}
	return 0;
}
