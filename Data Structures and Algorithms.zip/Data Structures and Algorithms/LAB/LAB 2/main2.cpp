#include <iostream>
using namespace std;
int main() {
	int size;
	cout<<"Enter size of Array: ";
	cin>>size;
	int *arr = new int[size];
	cout<<"Enter Values: ";
	for(int i=0;i<size;i++){
		cin>>arr[i];
	}
	int *max_add;
	int *min_add;
	int max = 0;
	for(int i =0;i<size;i++){
		if(max<arr[i]){
			max= arr[i];
			max_add = &arr[i];
		}
	}
	int min = max;
	for(int i =0;i<size;i++){
		if(arr[i]<min){
			min=arr[i];
			min_add = &arr[i];
		}
	}
	cout<<"Max="<<max<<endl;
	cout<<"Address of Max value: "<<max_add<<endl;
	cout<<"Min="<<min<<endl;
	cout<<"Address of Min value: "<<min_add<<endl;
	delete[] arr;
	return 0;
}
