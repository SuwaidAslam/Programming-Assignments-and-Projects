#include <iostream>

using namespace std;

struct node
{ 
    int data;
    node *next; 	
};

class linked_list
{
private:
    node *head,*tail;
public:
    linked_list()
    {
        head = NULL;
        tail = NULL;
    }

    void add_node(int n)
    {
        node *tmp = new node;
        tmp->data = n;
        tmp->next = NULL;

        if(head == NULL)
        {
            head = tmp;
            tail = tmp;
        }
        else
        {
            tail->next = tmp;
            tail = tail->next;
        }
    }
    
    void display()
    {
        node *tmp;
        tmp = head;
        while (tmp != NULL)
        {
            cout << tmp->data << endl;
            tmp = tmp->next;
        }
    }
    
    node* gethead()
    {
        return head;
    }
    
    void display1(node *head)
    {
        if(head == NULL)
        {
            cout << "NULL" << endl;
        }
        else
        {
            cout << head->data << endl;
            display1(head->next);
        }
    }
};

int main()
{
    linked_list a;
    a.add_node(10);
    a.add_node(20);
    a.add_node(90);

    //a.display();
    a.display1(a.gethead());
}
