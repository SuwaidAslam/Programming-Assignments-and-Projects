#include <iostream>

using namespace std;

struct node
{ 
    int data;
    node *next; 	
};

class linked_list
{
private:
    node *head,*tail;
public:
    linked_list()
    {
        head = NULL;
        tail = NULL;
    }

    void add_node(int n)
    {
        node *tmp = new node;
        tmp->data = n;
        tmp->next = NULL;

        if(head == NULL)
        {
            head = tmp;
            tail = tmp;
        }
        else
        {
            tail->next = tmp;
            tail = tail->next;
        }
    }
    
    void display()
    {
        node *tmp;
        tmp = head;
        while (tmp != NULL)
        {
            cout << tmp->data << endl;
            tmp = tmp->next;
        }
    }
    
    node* gethead()
    {
        return head;
    }
    
    void display1(node *head1)
    {
        if(head1 == NULL)
        {
            cout << "NULL" << endl;
        }
        else
        {
            cout << head1->data << endl;
            display1(head1->next);
        }
    }
    
    void del (node *before_del) // Delete at any location (after a particular node)
    {
        node* temp;
        temp = before_del->next;
        before_del->next = temp->next;
        delete temp;
    }
    void del1 (node *df) // Delete at any location (exactly a particular node)
    {
        if(head==df)
        {
        	node *temp;
        	temp=head;
        	head=head->next;
        	delete temp;
		}
		else
		{
			node *temp1= df->next;
			node *temp2=head;
			while(temp2->next!=df)
			{
				temp2=temp2->next;
			}
			temp2->next=temp1;
			delete df;
		}
    }

    
    void after(node *a, int value) //Insert at any location
    {
        node* p = new node;
        p->data = value;
        p->next = a->next;
        a->next = p;
    }
    
    static void concatenate1(node *temp1,node *temp2)
    {
    while(temp1->next!=NULL)
    	{
 			temp1=temp1->next;
		}
	temp1->next=temp2;	
		
    }
    
   static void concatenate2(linked_list temp1, linked_list temp2)
   { 
   temp1.tail->next=temp2.head;
   }
    
};

int main()
{
    linked_list a,b;
    a.add_node(100);
    a.add_node(200);
    a.add_node(300);
    a.add_node(400);
    a.add_node(500);
    
    b.add_node(4);
    b.add_node(5);
    
	//b.display();
   	//a.display1(a.gethead()); 
   	//a.del(a.gethead());
   	//a.del1(a.gethead());
	a.after(a.gethead()->next,1000);
   	linked_list::concatenate1(a.gethead(),b.gethead()); //static functions without objects
	//.concatenate2(a,b);
    a.display();  
}
