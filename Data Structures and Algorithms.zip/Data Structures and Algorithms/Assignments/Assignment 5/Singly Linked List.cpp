#include <iostream>
#include <conio.h>
using namespace std;

//1. Insertion at start
//2. Insertion at end
//3. Insertion at given position 
//4. Deletion at start
//5. Deletion at end
//6. Deletion at given position 
//7. Search key value
//8. Update value at given position 

struct Node
{
    int data;
    Node *next; 	
};

class LinkedList
{
private:
    Node *head,*tail;
public:
    LinkedList()
    {
        head = NULL;
        tail = NULL;
    }
    void insert_at_end(int);
    void insert_at_start(int);
    void insert_specific(int,int);
    void del_start();
    void del_end();
    void del_specific(int);
    void display();
    bool search(int);
    void Update_value(int, int);
};

void LinkedList::insert_at_start(int d){
	Node *temp;
	temp = new Node;
	temp->data = d;
	temp->next = NULL;

	// List is empty
	if(head == NULL){
		head = temp;
		tail = temp;
	}
	else{
		temp->next = head;
		head = temp;
	}
}

void LinkedList::insert_at_end(int n)
{
    Node *tmp = new Node;
    tmp->data = n;
    tmp->next = NULL;

    if(head == NULL)
    {
        head = tmp;
        tail = tmp;
    }
    else
    {
        tail->next = tmp;
        tail = tail->next;
    }
}

void LinkedList::display()
{
    Node *trav;
	trav = head;
	int count = 0;
	cout<<"List Data: ";
	while(trav != NULL)
	{
		count++;
		cout<<trav->data<<"  ";
		trav = trav->next;
	}
	cout<<"\nList has "<<count<<" Nodes."<<endl;
}

void LinkedList::del_start(){
	Node *temp;
	temp = head;
	head = head->next;
	delete temp;
}
void LinkedList::del_end(){
	Node *temp, *temp2;
	temp = tail;
	temp2 = head;
	if(temp2->next==NULL){
		head = NULL;
		tail = NULL;
		delete temp2;
	}
	else{
		while(temp2->next->next!=NULL)
			temp2 = temp2->next;
		
		tail = temp2;	
		temp2->next = NULL;
		delete temp;	
	}
}
bool LinkedList::search(int i){
	Node *current = head;
	while (current != NULL) {
		if(i == current->data){
			return true;
		}
        current = current->next;
    }
    return false;
}

void LinkedList::Update_value(int p, int n){
	Node *current = head;
	int index=0;
	while (current != NULL) {
		if(index == p){
			current->data = n;
			return;
		}
        current = current->next;
        index++;
    }
    cout<<"index Out of Range!"<<endl;
}
void LinkedList::del_specific(int n){
	Node *current = head;
	Node *prev = head;
	int index=0;
	if(n == 0){
		head = current->next;
		delete current;
	}
	else{
		while (current != NULL) {
		if(index == n){
			prev->next = current->next;
			delete current;
			return;
		}
		prev = current;
        current = current->next;
        index++;
    }
    	cout<<"index Out of Range!"<<endl;
	}
}

void LinkedList::insert_specific(int p, int n){
	Node *New = new Node;
	New->data = n;
	New->next = NULL;
	Node *current = head;
	Node *prev = head;
	int index=0;
	if(p == 0){
		New->next = head;
		head = New;
	}
	else{
		while (current != NULL) {
		if(index == p){
			prev->next = New;
			New->next = current;
			return;
		}
		prev = current;
        current = current->next;
        index++;
    }
    	cout<<"index Out of Range!"<<endl;
	}
}
int main()
{
	LinkedList list;
	bool Runing = true;
	int option = 0;
	while (Runing)
	{
		system("CLS");
		cout << "\t\t\t\t-----Singly Linked List------\n";
		cout << "\t\t\t\t1-Insert At Start\n";
		cout << "\t\t\t\t2-Insert At End\n";
		cout << "\t\t\t\t3-Insert at given position\n";
		cout << "\t\t\t\t4-Deletion at start\n";
		cout << "\t\t\t\t5-Deletion at end\n";
		cout << "\t\t\t\t6-Deletion at given position\n";
		cout << "\t\t\t\t7-Search key value\n";
		cout << "\t\t\t\t8-Update value at given position \n";
		cout << "\t\t\t\t9-Display List\n";
		cout << "\t\t\t\t10-Exit\n";
		cout << "Enter Option: ";
		cin >> option;
		switch(option) {
		case 1:
			cout<<"Enter a Value: ";
			int i;
			cin>>i;
			list.insert_at_start(i);
			getch();
			break;
		case 2:
			cout<<"Enter a Value: ";
			int j;
			cin>>j;
			list.insert_at_end(j);
			getch();
			break;
		case 3:
			cout<<"Enter the value to insert:";
			int vl, ps;
			cin>>vl;
			cout<<"Enter the position:";
			cin>>ps;
			list.insert_specific(ps,vl);
			getch();
			break;
		case 4:
			list.del_start();
			cout<<"Done!"<<endl;
			getch();
			break;
		case 5:
			list.del_end();
			cout<<"Done!"<<endl;
			getch();
			break;
		case 6:
			cout<<"Enter the Position: ";
			int p;
			cin>>p;
			list.del_specific(p);
			getch();
			break;
		case 7:
			cout<<"Enter Value to Search:";
			int k;
			cin>>k;
			if(list.search(k)){
				cout<<"This Value is present in the list"<<endl;
			}
			else{
				cout<<"This Value does not exist in the list"<<endl;
			}
			getch();
			break;
		case 8:
			cout<<"Enter the value to update:";
			int val, pos;
			cin>>val;
			cout<<"Enter the position:";
			cin>>pos;
			list.Update_value(pos,val);
			getch();
			break;
		case 9:
			list.display();
			getch();
			break;
		default:
			Runing = false;
			cout << "Press Any key to Continue...!";
			getch();
		}
	}
	return 0;
}
