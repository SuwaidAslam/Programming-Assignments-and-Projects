#include<iostream>
#include <conio.h>
using namespace std;
const int SIZE = 13;	
// With Linear Probing
struct DataElement{
	bool filled = false;
	int data = -1;
	int key;
};
class HashTable{
	private:
		DataElement DataTable[SIZE];
	public:
		int hashCode(int);
		void insert(int);
		void display();
		void Delete(int);
		void Search(int);
		bool isFull();
};
int HashTable::hashCode(int key){
	return key % SIZE;
}
void HashTable::insert(int data) {
   //get the hash 
   bool Notpresent = true;
   int hashIndex = hashCode(data);
   //move in array until an empty or deleted cell
   while(DataTable[hashIndex].filled != false){
      //go to next cell
      if(DataTable[hashIndex].data == data)
      		Notpresent = false;
      ++hashIndex;
      hashIndex %= SIZE;
      if(isFull()){
      	cout<<"Table is Full!"<<endl;
      	return;
	  }
   }
   if(Notpresent){
	   DataTable[hashIndex].filled = true;
	   DataTable[hashIndex].data = data;
	   DataTable[hashIndex].key = hashIndex;
   }
   else
   	cout<<"Eelement Already exist in Table!"<<endl;
}
void HashTable::display(){
	for(int i=0;i<SIZE; i++){
		if(DataTable[i].data != -1)
			cout<<i<<"->"<<DataTable[i].data<<endl;
	}
}
void HashTable::Search(int data){
	//get the hash 
   int hashIndex = hashCode(data);
   int j = 1;
   //move in array until an empty or deleted cell
   while(DataTable[hashIndex].data != data && DataTable[hashIndex].filled != false){
      //go to next cell
      if(j == SIZE+1)
      	break;
      ++hashIndex;
	  hashIndex %= SIZE;
	  j++;
   }
   if(DataTable[hashIndex].filled == false || j == SIZE+1)
   			cout<<"Not Found!"<<endl;
	else{
		cout<<"Value of the Element: "<<DataTable[hashIndex].data<<endl;
   		cout<<"Index of the Element: "<<DataTable[hashIndex].key;
	}
}
void HashTable::Delete(int data){
	//get the hash 
   int hashIndex = hashCode(data);
   int j = 1;
   //move in array until an empty or deleted cell
   while(DataTable[hashIndex].data != data && DataTable[hashIndex].filled != false){
      //go to next cell
      if(j == SIZE+1)
      	break;
      ++hashIndex;
      hashIndex %= SIZE;
      j++;
   }
   if(DataTable[hashIndex].filled == false || j == SIZE+1)
   			cout<<"Not Found!"<<endl;
	else{
		DataTable[hashIndex].data = -1;
   		DataTable[hashIndex].filled = false;
	}
}
bool HashTable::isFull(){
	int counter = 0;
	for(int i=0;i<SIZE; i++){
		if(DataTable[i].data != -1)
			counter++;
	}
	if(counter == SIZE)
		return true;
	else
		return false;
}
HashTable hashTable;
void ArrayInsert(){
	int Arry[] = {13, 47, 75, 27, 90, 58, 14, 98, 25, 77, 184, 664, 142, 742, 136, 074, 158, 243, 111, 41};
	int size = sizeof(Arry)/sizeof(*Arry);
	for(int i=0; i<size; i++){
		hashTable.insert(Arry[i]);
	}
}

int main() {
	bool Runing = true;
	int option = 0;
	while(Runing)
	{
		system("CLS");
		cout << "\t\t\tHash Table -> Linear Probing\n";
		cout << "\t\t\t\t1-Insert\n";
		cout << "\t\t\t\t2-Delete\n";
		cout << "\t\t\t\t3-Display\n";
		cout << "\t\t\t\t4-Search\n";
		cout << "\t\t\t\t5-Exit\n";
		cout << "Enter Option: ";
		cin >> option;
		switch(option) {
		case 1:
			ArrayInsert();
			break;
		case 2:
			int n;
			cout<<"Enter Element Value to be deleted: ";
			cin>>n;
			hashTable.Delete(n);
			getch();
			break;
		case 3:
			hashTable.display();
			getch();
			break;
		case 4:
			int a;
			cout<<"Enter Value to be Search: ";
			cin>>a;
			hashTable.Search(a);
			getch();
			break;
		case 5:
			Runing = false;
			cout << "Press Any key to Continue...!";
			getch();
			break;
		default:
			cout << "Invalid Choice!";
			getch();
		}
	}
	
   return 0;
}
