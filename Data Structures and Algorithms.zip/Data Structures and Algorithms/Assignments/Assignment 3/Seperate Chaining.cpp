#include<iostream>
#include <conio.h>
using namespace std;
const int SIZE = 13;	
// With Seperate Chaining
struct node
{
    int data;
    node *next;
};
struct DataElement{
	bool filled = false;
	int data = -1;
	int key;
	node *next = NULL;
};
class HashTable{
	private:
		DataElement DataTable[SIZE];
	public:
		int hashCode(int);
		void insert(int);
		void display();
		void Delete(int);
		void Search(int);
		bool isFull();
};

int HashTable::hashCode(int key){
	return key % SIZE;
}
void HashTable::insert(int data) {
   //get the hash 
   bool Notpresent = true;
   int hashIndex = hashCode(data);
   if(isFull()){
   	cout<<"Table is Full!";
   	return ;
   }
   //if collision occures add a node
   if(DataTable[hashIndex].filled)
   {
   	node *temp = new node;
   	temp->data = data;
   	temp->next = NULL;
   	if(DataTable[hashIndex].next == NULL)
   		DataTable[hashIndex].next = temp;
   	else{
   		node *temp1 = DataTable[hashIndex].next;
   		while(temp1->next!=NULL)
   			temp1 = temp1->next;
		temp1->next = temp;
	}
   }
   else{
	   DataTable[hashIndex].filled = true;
	   DataTable[hashIndex].data = data;
	   DataTable[hashIndex].key = hashIndex;
   }
}
void HashTable::display(){
	for(int i=0;i<SIZE; i++){
		if(DataTable[i].data != -1){
			cout<<i<<"=> "<<DataTable[i].data<<" ";
			if(DataTable[i].next != NULL){
				node *tmp = DataTable[i].next;
				while(tmp!=NULL){
					cout<<tmp->data<<" ";
					tmp = tmp->next;
				}
			}
			cout<<endl;
		}
	}
}
void HashTable::Search(int data){
	//get the hash 
   int hashIndex = hashCode(data);
	if(DataTable[hashIndex].data !=data)
	{
	   	node *temp1 = DataTable[hashIndex].next;
	   	if(temp1 != NULL){
	   	while(temp1->next!=NULL && temp1->data != data)
	   		temp1 = temp1->next;
		if(temp1->data == data){
			cout<<"Value of the Element: "<<temp1->data<<endl;
   			cout<<"Index of the Element: "<<DataTable[hashIndex].key;
		}
		else
			cout<<"Element Does not exist!"<<endl;	
	}
	else
		cout<<"Element Does not exist!"<<endl;	
	}
	else{
		cout<<"Value of the Element: "<<DataTable[hashIndex].data<<endl;
   		cout<<"Index of the Element: "<<DataTable[hashIndex].key;
	}
}
void HashTable::Delete(int data){
	//get the hash 
   int hashIndex = hashCode(data);
   if(DataTable[hashIndex].data !=data)
	{
	   	node *temp1 = DataTable[hashIndex].next;
	   	node *last = NULL;
	   	while(temp1->next!=NULL && temp1->data != data){
	   		last = temp1;
	   		temp1 = temp1->next;
		}
		if(temp1->data == data && last != NULL){
			last->next = temp1->next;
			delete temp1;
		}
		else if(temp1->data == data && last == NULL){
			 DataTable[hashIndex].next = temp1->next;
			delete temp1;
		}
		else
			cout<<"Element Does not exist!"<<endl;
	}
	else if(DataTable[hashIndex].filled && DataTable[hashIndex].data ==data){
		DataTable[hashIndex].data = -2;
   		DataTable[hashIndex].filled = false;
	}
	else
		cout<<"Item Not Found!"<<endl;
}
bool HashTable::isFull(){
	int counter = 0;
	for(int i=0;i<SIZE; i++){
		if(DataTable[i].data != -1)
			counter++;
	}
	if(counter == SIZE)
		return true;
	else
		return false;
}
HashTable hashTable;
void ArrayInsert(){
	int Arry[] = {13, 47, 75, 27, 90, 58, 14, 98, 25, 77, 184, 664, 142, 742, 136, 074, 158, 243, 111, 41};
	int size = sizeof(Arry)/sizeof(*Arry);
	for(int i=0; i<size; i++){
		hashTable.insert(Arry[i]);
	}
}

int main() {
	bool Runing = true;
	int option = 0;
	while(Runing)
	{
		system("CLS");
		cout << "\t\t\tHash Table -> Seperate Chaining\n";
		cout << "\t\t\t\t1-Insert\n";
		cout << "\t\t\t\t2-Delete\n";
		cout << "\t\t\t\t3-Display\n";
		cout << "\t\t\t\t4-Search\n";
		cout << "\t\t\t\t5-Exit\n";
		cout << "Enter Option: ";
		cin >> option;
		switch(option) {
		case 1:
			ArrayInsert();
			break;
		case 2:
			int n;
			cout<<"Enter Element Value to be deleted: ";
			cin>>n;
			hashTable.Delete(n);
			getch();
			break;
		case 3:
			hashTable.display();
			getch();
			break;
		case 4:
			int a;
			cout<<"Enter Value to be Search: ";
			cin>>a;
			hashTable.Search(a);
			getch();
			break;
		case 5:
			Runing = false;
			cout << "Press Any key to Continue...!";
			getch();
			break;
		default:
			cout << "Invalid Choice!";
			getch();
		}
	}
	
   return 0;
}
