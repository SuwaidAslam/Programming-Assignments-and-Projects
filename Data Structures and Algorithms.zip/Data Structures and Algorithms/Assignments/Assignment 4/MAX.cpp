#include <iostream>
#include <conio.h>
//Max Heap
using namespace std;
#define max_size 20

class MAX
{
		int array[max_size];
		int pos;
	public:
		MAX()
		{
			pos = 0;
		}
		void Insert(int);
		void Display(int, int);
		void Search(int);
		void Delete(int);
		void heapify(int);
		int P(int);
		int L(int);
		int R(int);
};
void MAX::Insert(int d){
	if(pos == max_size-1){
		cout<<"Heap is FULL!"<<endl;
		return;

	}
	if(pos == 0){
		pos++;
		array[pos] = d;
	}
	else{
		pos++;
		array[pos] = d;
		int tmp_pos = pos;
		int parent;
		while(array[P(tmp_pos)] < array[tmp_pos]){
			parent = array[P(tmp_pos)];
			array[P(tmp_pos)] = array[tmp_pos];
			array[tmp_pos] = parent;
			tmp_pos = P(tmp_pos);
		}
	}
}
void MAX::Display(int space, int p){
	if(p > pos)
		return;
	space+= 5;
	int l = L(p);
	int r = R(p);
	Display(space, r);
	cout<<endl;
	for(int j=5; j<space; j++)
		cout<<" ";
	cout<<array[p];
	Display(space, l);
}

void MAX::Search(int v){
	for(int i=1; i<=pos; i++){
		if(v == array[i]){
			cout<<"Element Found!"<<endl;
			return;
		}
	}
	cout<<"Element Not Found!"<<endl;
}
void MAX::Delete(int v){
	for(int i=1; i<=pos; i++){
		if(v == array[i]){
			array[i] = array[pos];
			pos--;
			heapify(i);
			return;
		}
	}
	cout<<"Element Not Found!"<<endl;
	
}
void MAX::heapify(int i){
	int largest = i;
	int L_Child = L(i);
	int R_Child = R(i);
	
	// If left child is larger than root
    if (L_Child <= pos && array[L_Child] > array[largest])
        largest = L_Child;
  
    // If right child is larger than largest so far
    if (R_Child <= pos && array[R_Child] > array[largest])
        largest = R_Child;
  
    // If largest is not root
    if (largest != i) {
    	int j = array[i];
    	array[i] = array[largest];
    	array[largest] = j;
  
        // Recursively heapify the affected sub-tree
        heapify(largest);
    }
}
int MAX::P(int i) {return i/2;}
int MAX::L(int i) {return 2 * i;}
int MAX::R(int i) {return (2 * i) + 1;}


int main()
{
	MAX max_heap;
	bool Runing = true;
	int option = 0;
	while(Runing)
	{
		system("CLS");
		cout << "\t\t\t\t-----Max Heap Tree------\n";
		cout << "\t\t\t\t1-Input\n";
		cout << "\t\t\t\t2-Display\n";
		cout << "\t\t\t\t3-Search\n";
		cout << "\t\t\t\t4-Delete\n";
		cout << "\t\t\t\t5-Exit\n";
		cout << "Enter Option: ";
		cin >> option;
		switch(option) {
		case 1:
			int option;
			do{
				int v;
				cout<<"Enter Value: ";
				cin>>v;
				max_heap.Insert(v);
				cout<<"Add one more Node?(1/0): ";
				cin>>option;
			}while(option==1);
			getch();
			break;
		case 2:
			max_heap.Display(5, 1);
			getch();
			break;
		case 3:
			cout<<"Enter Value to Search: ";
			int value;
			cin>>value;
			max_heap.Search(value);
			getch();
			break;
		case 4:
			cout<<"Enter Value to delete: ";
			int val;
			cin>>val;
			max_heap.Delete(val);
			getch();
			break;
		case 5:
			Runing = false;
			cout << "Press Any key to Continue...!";
			getch();
			break;
		default:
			cout << "Invalid Choice!";
			getch();
		}
	}
	return 0;
}
