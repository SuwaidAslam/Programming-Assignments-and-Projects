#include<iostream>
#include <conio.h>
#include <string>
using namespace std;
const int max_employees = 10;
class Person{
	private:
		string FirstName;
		string LastName;
		static int PersonalID_Static;
		int PersonalID;
		double Salary;
	public:
		void set_FirstName(string Fname){
			FirstName = Fname;
		}
		void set_LastName(string Lname){
			LastName = Lname;
		}
		void set_PersonalID(){
			PersonalID_Static++;
			PersonalID = PersonalID_Static;
		}
		void set_Salary(double pay){
			Salary = pay;
		}
		string get_FirstName(){
			return FirstName;
		}
		string get_LastName(){
			return LastName;
		}
		int get_PersonalID(){
			return PersonalID;
		}
		double get_Salary(){
			return Salary;
		}
};
int Person::PersonalID_Static = 8248001;
class HRM{
	private:
		Person* employees[max_employees];
		int total_employees;
	public:
		HRM(): total_employees(-1){}
		void AddPerson(){
			if(total_employees>=max_employees){
				cout<<"Employees are Full!"<<endl;
			}
			else{
				Person *person = new Person;
				string FName, LName;
				double salary;
				cout<<"Enter the information of new employee:"<<endl;
				cout<<"First Name = ";
				cin>>FName;
				cout<<"Last Name = ";
				cin>>LName;
				cout<<"How much is her/his salary?= ";
				cin>>salary;
				person->set_FirstName(FName);
				person->set_LastName(LName);
				person->set_PersonalID();
				person->set_Salary(salary);
				total_employees++;
				employees[total_employees] = person;
				
				cout<<"The Employee with the following information has been added to the system:\n";
				cout<<"First Name\tLast Name\tPersonal ID\tSalary per year (Rupees)\n";
				cout<<"----------\t----------\t----------\t----------\n";
				cout<<person->get_FirstName()<<"\t\t"<<person->get_LastName()<<"\t\t"<<person->get_PersonalID()<<"\t\t"<<person->get_Salary()<<endl;
				cout<<"Do you want to add another employee? (y/n)";
				char ch;
				cin>>ch;
				if(ch=='y')
					this->AddPerson();
			}
		}
		void DeletePerson(){
			cout<<"ID of employee to remove: ";
			int id;
			cin>>id;
			cout<<"Do you really want to delete employee (y/n)?:";
			char chr;
			cin>>chr;
			if(chr=='y'){
				for(int i=0;i<=total_employees;i++){
					if(employees[i]->get_PersonalID() == id){
						Person *person = employees[i];
						for(int j=i;j<=total_employees; j++)
							employees[j] = employees[j+1];
						total_employees--;
						cout<<"The Employee with the following information has been Deleted from the system:\n";
						cout<<"First Name\tLast Name\tPersonal ID\tSalary per year (Rupees)\n";
						cout<<"----------\t----------\t----------\t----------\n";
						cout<<person->get_FirstName()<<"\t\t"<<person->get_LastName()<<"\t\t"<<person->get_PersonalID()<<"\t\t"<<person->get_Salary()<<endl;
						return;
					}
				}
			}
			else{
				return;
			}
			cout<<"Employee Not Found!"<<endl;
			
		}
		void UpdatePerson(){
			int id;
			cout<<"Enter Employee ID to modify Data: ";
			cin>>id;
			for(int i=0;i<=total_employees;i++){
				int Pid = employees[i]->get_PersonalID();
					if(Pid == id){
						cout<<"Please enter the related number of feild which would like to update:\n";
						cout<<"1. First Name\n";
						cout<<"2. Family Name\n";
						cout<<"3. Monthly Salary\n";
						int n;
						cin>>n;
						switch(n){
							case 1:{
								cout<<"First Name: ";
								string Fname;
								cin>>Fname;
								employees[i]->set_FirstName(Fname);
								break;
							}
							case 2:{
								cout<<"Family Name: ";
								string Lname;
								cin>>Lname;
								employees[i]->set_LastName(Lname);
								break;
							}
							case 3:{
								cout<<"Monthly Salary: ";
								double salary;
								cin>>salary;
								employees[i]->set_Salary(salary);
								break;
							}
						}
						Person *person = employees[i];
						cout<<"The Employee with the following information has been added to the system:\n";
						cout<<"First Name\tLast Name\tPersonal ID\tSalary per year (Rupees)\n";
						cout<<"----------\t----------\t----------\t----------\n";
						cout<<person->get_FirstName()<<"\t\t"<<person->get_LastName()<<"\t\t"<<person->get_PersonalID()<<"\t\t"<<person->get_Salary()<<endl;
						return;
					}
			}
			cout<<"Employee Not found!"<<endl;
			
		}
};
//Main the Driver
int main(){
	bool Runing = true;
	int option;
	HRM hrm;
	while(Runing)
	{
		system("CLS");
		cout<"Welcome Abroad...\n";
		cout<<"*********************************************************************\n\n\n";
		cout<<"Welcome to Human Resource Management (HRM) Software of Company XYZ. To do specific task please choose one of the following commands.\n\n";
		cout<<"\t1. Add new employee\n";
		cout<<"\t2. Delete employee Information\n";
		cout<<"\t3. Update employee Information\n";
		cout<<"\t4. Quite\n";
		cout << "Enter Option: ";
		cin >> option;
		switch(option) {
			case 1:{
				hrm.AddPerson();
				break;
			}
			case 2:{
				hrm.DeletePerson();
				getch();
				break;
			}
			case 3:{
				hrm.UpdatePerson();
				getch();
				break;
			}
			case 4:{
				Runing = false;
				break;
			}
			default:{
				cerr << "Invalid Choice!";
				getch();
			}
		}
	}
	return 0;
}
