#include<iostream>
#include <conio.h>
using namespace std;
struct node
{ 	
    int data;
    node *next;
    node *prev;
};
class Queue{
	private:
		node *front;
		node *rear;
	public:
		Queue(){
			front = NULL;
			rear = NULL;
		}
		void Enqueue(int);
		void Dequeue();
		bool IsEmpty();
		int Peek();
		void Display_Rear();
		void Display_Front();
};
void Queue::Enqueue(int x)
{
    node *temp = new node;
    temp->data = x;
    temp->next = NULL;
    temp->prev = NULL;
    if(front == NULL)
    {
        front = temp;
        rear = temp;
        front->prev = NULL;
        rear->next = NULL;
    }
    else
    {
    	node *temp1 = rear;
        rear->next = temp;
        rear = temp;
        rear->prev = temp1;
        rear->next = NULL;
    }
}
void Queue::Dequeue()
{
    if(front == NULL)
    {
        cout<<"Queue is Empty\n";
    }
    else
    {
    	if(front->next == NULL){
    		front = NULL;
    		rear = NULL;
		}
		else{
			node *temp = front;
	        front = front->next;
	        front->prev = NULL;
	        delete temp;
		}
    }
}
bool Queue::IsEmpty(){
	return (front == NULL) ? true : false;
}
int Queue::Peek(){
	if(front == NULL)
		cout<<"Queue is Empty!"<<endl;
	else
		return front->data;
}
void Queue::Display_Rear(){
	node *temp = rear;
	cout<<"Queue Data from Rear: ";
	while(temp!=NULL){
		cout<<temp->data<<" ";
		temp = temp->prev;
	}
	cout<<endl;
}
void Queue::Display_Front(){
	node *temp = front;
	cout<<"Queues Data from Front: ";
	while(temp!=NULL){
		cout<<temp->data<<" ";
		temp = temp->next;
	}
	cout<<endl;
}
int main()
{
	Queue queue;
	bool Runing = true;
	int option = 0;
	while(Runing)
	{
		system("CLS");
		cout << "\t\t\t\t-----Queue using Doubly Linked List------\n";
		cout << "\t\t\t\t1-En-Queue\n";
		cout << "\t\t\t\t2-De-Queue\n";
		cout << "\t\t\t\t3-Display Queue from Rear\n";
		cout << "\t\t\t\t4-Display Queue from Front\n";
		cout << "\t\t\t\t5-Check if the Queue is Empty\n";
		cout << "\t\t\t\t6-Exit\n";
		cout << "Enter Option: ";
		cin >> option;
		switch(option) {
		case 1:
			char option;
			do{
				int v;
				cout<<"Enter Value: ";
				cin>>v;
				queue.Enqueue(v);
				cout<<"Add one more Node?(1/0): ";
				cin>>option;
			}while(option=='1');
			break;
		case 2:
			queue.Dequeue();
			getch();
			break;
		case 3:
			queue.Display_Rear();
			getch();
			break;
		case 4:
			queue.Display_Front();
			getch();
			break;
		case 5:
			if(queue.IsEmpty())
				cout<<"Queue is Empty!"<<endl;
			else
				cout<<"Queue is not Empty!"<<endl;
			getch();
			break;
		case 6:
			Runing = false;
			cout << "Press Any key to Continue...!";
			getch();
			break;
		default:
			cout << "Invalid Choice!";
			getch();
		}
	}
}
